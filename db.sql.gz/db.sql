/*!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.11.8-MariaDB, for debian-linux-gnu (aarch64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.8-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` text NOT NULL,
  `icon` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `identifier` varchar(120) NOT NULL DEFAULT '',
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(120) NOT NULL DEFAULT '',
  `widgets` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1718360189,1718360189,0,0,0,0,'a918e733d0a50b918676924f21e95efce874be2e',1,'My dashboard','{\"3ec5ee6943879df8fdb17ebc7471dbf4a6fa27a6\":{\"identifier\":\"t3information\"},\"d8ab6f78535a2148e904690018416c4fb84d6df4\":{\"identifier\":\"docGettingStarted\"}}');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `non_exclude_fields` text DEFAULT NULL,
  `explicit_allowdeny` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` text DEFAULT NULL,
  `db_mountpoints` text DEFAULT NULL,
  `pagetypes_select` text DEFAULT NULL,
  `tables_select` text DEFAULT NULL,
  `tables_modify` text DEFAULT NULL,
  `groupMods` text DEFAULT NULL,
  `availableWidgets` text DEFAULT NULL,
  `mfa_providers` text DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `subgroup` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `username` varchar(50) NOT NULL DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `password` varchar(255) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `usergroup` text DEFAULT NULL,
  `lang` varchar(10) NOT NULL DEFAULT 'default',
  `email` varchar(255) NOT NULL DEFAULT '',
  `db_mountpoints` text DEFAULT NULL,
  `options` smallint(5) unsigned NOT NULL DEFAULT 0,
  `realName` varchar(80) NOT NULL DEFAULT '',
  `userMods` text DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `uc` mediumblob DEFAULT NULL,
  `file_mountpoints` text DEFAULT NULL,
  `file_permissions` text DEFAULT NULL,
  `workspace_perms` smallint(6) NOT NULL DEFAULT 1,
  `TSconfig` text DEFAULT NULL,
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `category_perms` longtext DEFAULT NULL,
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `password_reset_token` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1718360182,1718360182,0,0,0,0,NULL,'t3admin',0,'$argon2i$v=19$m=65536,t=16,p=1$NEUwd241U2JmYm5DMTMxUg$tSd/wSY2wzuWL741SB3ywVioATAvWfvokb3v1N3JJ/8',1,NULL,'default','annie.ezc@gmail.com',NULL,0,'',NULL,'','a:8:{s:10:\"moduleData\";a:17:{s:28:\"dashboard/current_dashboard/\";s:40:\"a918e733d0a50b918676924f21e95efce874be2e\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:10:\"FormEngine\";a:2:{i:0;a:1:{s:32:\"7379749a99e9acb386dd0e97c5e558df\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:20;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B20%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:20;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=2ba1874e885ee497e8e8e87dc75b338910700193&id=1&\";}}i:1;s:32:\"7379749a99e9acb386dd0e97c5e558df\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:19:\"pagetsconfig_active\";}s:6:\"web_ts\";a:1:{s:6:\"action\";s:29:\"web_typoscript_constanteditor\";}s:16:\"opendocs::recent\";a:8:{s:32:\"86205c5935270b8ee413592ec1b62292\";a:5:{i:0;s:15:\"dengram package\";i:1;a:5:{s:4:\"edit\";a:1:{s:12:\"sys_template\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:35:\"&edit%5Bsys_template%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:12:\"sys_template\";s:3:\"uid\";i:1;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:108:\"/typo3/module/web/typoscript/overview?token=05bd26d5cd8264627219116b4b41bf673d7f06da&id=1&selectedTemplate=1\";}s:32:\"22cbd9b921ab5848edaac19c41752085\";a:5:{i:0;s:9:\"Some Text\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:19;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B19%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:19;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=62523c9a5c792ac3e96b5f5b15d5bdbfb85b20e6&id=1&\";}s:32:\"9b967901d6c9df7fbe10e9cd1eacc0fe\";a:5:{i:0;s:7:\"Dengram\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";a:1:{s:5:\"pages\";a:1:{s:16:\"sys_language_uid\";s:1:\"0\";}}s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:76:\"&edit%5Bpages%5D%5B1%5D=edit&overrideVals%5Bpages%5D%5Bsys_language_uid%5D=0\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:216:\"/typo3/record/edit?token=f5c4967504c0e4117f444297bd9d51137106f16d&edit%5Btt_content%5D%5B10%5D=edit&returnUrl=/typo3/module/web/layout?token%3D5af7b6e8d239cd5593b20718d5742430f3b3c42a%26id%3D1%23element-tt_content-10\";}s:32:\"ffbd6ae78a9aa555f88d6295c30fb80c\";a:5:{i:0;s:11:\"top members\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:10;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B10%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:10;s:3:\"pid\";i:1;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=5af7b6e8d239cd5593b20718d5742430f3b3c42a&id=1#element-tt_content-10\";}s:32:\"aaca9201f0dfcd055cfed79781490cc6\";a:5:{i:0;s:8:\"tm2.jpeg\";i:1;a:5:{s:4:\"edit\";a:1:{s:17:\"sys_file_metadata\";a:1:{i:9;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:40:\"&edit%5Bsys_file_metadata%5D%5B9%5D=edit\";i:3;a:5:{s:5:\"table\";s:17:\"sys_file_metadata\";s:3:\"uid\";i:9;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:231:\"/typo3/record/edit?token=78445b94cd8ca64f5324bc035b739b476dd7971c&edit%5Btx_news_domain_model_news%5D%5B3%5D=edit&returnUrl=/typo3/module/web/list%3Ftoken%3D2880bde05de944af34bce6dd2ae15c5fda894f3a%26id%3D8%26table%3D%26pointer%3D1\";}s:32:\"696addfecc296b326ff6e9f04c7ff3e1\";a:5:{i:0;s:7:\"Dengram\";i:1;a:5:{s:4:\"edit\";a:1:{s:5:\"pages\";a:1:{i:1;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:28:\"&edit%5Bpages%5D%5B1%5D=edit\";i:3;a:5:{s:5:\"table\";s:5:\"pages\";s:3:\"uid\";i:1;s:3:\"pid\";i:0;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:76:\"/typo3/module/web/layout?token=a500d6b0d5e80ef16ceeb17fb86c9c7ca0958a67&id=1\";}s:32:\"450f1cb96fe4491e1e76cb7e67ee5dd8\";a:5:{i:0;s:0:\"\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:18;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B18%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:18;s:3:\"pid\";i:10;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:77:\"/typo3/module/web/layout?token=a500d6b0d5e80ef16ceeb17fb86c9c7ca0958a67&id=10\";}s:32:\"1edd15adf43123aaf034d44a97cf558b\";a:5:{i:0;s:13:\"Search result\";i:1;a:5:{s:4:\"edit\";a:1:{s:10:\"tt_content\";a:1:{i:16;s:4:\"edit\";}}s:7:\"defVals\";N;s:12:\"overrideVals\";N;s:11:\"columnsOnly\";N;s:6:\"noView\";N;}i:2;s:34:\"&edit%5Btt_content%5D%5B16%5D=edit\";i:3;a:5:{s:5:\"table\";s:10:\"tt_content\";s:3:\"uid\";i:16;s:3:\"pid\";i:4;s:3:\"cmd\";s:4:\"edit\";s:12:\"deleteAccess\";b:1;}i:4;s:98:\"/typo3/module/web/layout?token=a500d6b0d5e80ef16ceeb17fb86c9c7ca0958a67&id=4#element-tt_content-16\";}}s:38:\"tools_ExtensionmanagerExtensionmanager\";a:1:{s:6:\"filter\";s:5:\"Local\";}s:8:\"web_info\";a:1:{s:6:\"action\";s:17:\"web_info_overview\";}s:17:\"web_info_overview\";a:2:{s:5:\"pages\";s:1:\"0\";s:5:\"depth\";s:1:\"2\";}s:25:\"web_typoscript_infomodify\";a:1:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}}s:15:\"system_BelogLog\";a:1:{s:10:\"constraint\";s:334:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:0:\"\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:16:\"browse_links.php\";a:2:{s:10:\"expandPage\";s:1:\"4\";s:12:\"expandFolder\";s:20:\"1:/dengram/old-boys/\";}s:29:\"web_typoscript_constanteditor\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:16:\"selectedCategory\";s:35:\"bootstrap package: content elements\";}s:17:\"typoscript_active\";a:6:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}s:12:\"page_preview\";a:1:{s:6:\"States\";a:1:{s:7:\"current\";a:3:{s:5:\"width\";s:3:\"411\";s:6:\"height\";s:3:\"731\";s:5:\"label\";s:8:\"Nexus 6P\";}}}s:16:\"extensionbuilder\";a:1:{s:9:\"firstTime\";i:0;}s:23:\"web_typoscript_analyzer\";a:3:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:16:{s:28:\"dashboard/current_dashboard/\";s:40:\"d0d42c12cdf1edc14b7e1ff59bc0ac810ed6ca7e\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"34b37a32a0c7bc1988bfdf8a0ecaf7781c602fac\";s:10:\"FormEngine\";s:40:\"34b37a32a0c7bc1988bfdf8a0ecaf7781c602fac\";s:12:\"pagetsconfig\";s:40:\"324842653eb523f34f428107dd06628bb6b39f12\";s:6:\"web_ts\";s:40:\"9407e0a5da1a7fc0f058817f8e6b0be5b30413db\";s:16:\"opendocs::recent\";s:40:\"9407e0a5da1a7fc0f058817f8e6b0be5b30413db\";s:38:\"tools_ExtensionmanagerExtensionmanager\";s:40:\"6001e0e484a18309349ef7bac4bf06e26658a345\";s:8:\"web_info\";s:40:\"6001e0e484a18309349ef7bac4bf06e26658a345\";s:17:\"web_info_overview\";s:40:\"d0d42c12cdf1edc14b7e1ff59bc0ac810ed6ca7e\";s:25:\"web_typoscript_infomodify\";s:40:\"6001e0e484a18309349ef7bac4bf06e26658a345\";s:15:\"system_BelogLog\";s:40:\"6001e0e484a18309349ef7bac4bf06e26658a345\";s:16:\"browse_links.php\";s:40:\"305ee4e8a6643d69fcbea2c2d0fcdd0298ad2496\";s:29:\"web_typoscript_constanteditor\";s:40:\"9407e0a5da1a7fc0f058817f8e6b0be5b30413db\";s:17:\"typoscript_active\";s:40:\"65f6e9b0ac47d8836501b5cd080e8f6fb98955f7\";s:16:\"extensionbuilder\";s:40:\"7bb925d500960b87d1a7bb847ef9736fe0e914f5\";s:23:\"web_typoscript_analyzer\";s:40:\"2c9b36d1c6c8d6eff56d72e5522cf71696a20ddf\";}s:17:\"BackendComponents\";a:1:{s:6:\"States\";a:2:{s:8:\"Pagetree\";a:1:{s:9:\"stateHash\";a:2:{s:3:\"0_1\";s:1:\"1\";s:3:\"0_4\";s:1:\"1\";}}s:15:\"FileStorageTree\";a:1:{s:9:\"stateHash\";a:1:{s:10:\"1_59663721\";s:1:\"0\";}}}}s:10:\"modulemenu\";s:2:\"{}\";s:10:\"inlineView\";s:521:\"{\"tt_content\":{\"NEW667029a605004575079441\":{\"sys_file_reference\":[1]},\"NEW66702b4987018442816600\":{\"sys_file_reference\":[2]}},\"pages\":{\"1\":{\"sys_file_reference\":[3]},\"4\":{\"sys_file_reference\":[7]},\"10\":{\"sys_file_reference\":[8]},\"11\":{\"sys_file_reference\":[9]}},\"tx_news_domain_model_news\":{\"NEW667413e38088c107554856\":{\"sys_file_reference\":[4]},\"NEW667468bbf0530292618925\":{\"sys_file_reference\":[5]},\"2\":{\"sys_file_reference\":[6]},\"NEW6675a7eac2a85800999301\":{\"sys_file_reference\":[10]},\"3\":{\"sys_file_reference\":[11]}}}\";}',NULL,NULL,1,NULL,0,NULL,NULL,1724859039,''),
(2,0,1718382637,1718382637,0,0,0,0,NULL,'_cli_',0,'$argon2i$v=19$m=65536,t=16,p=1$dFhpTWpFWXYvVWZ6SjVIbg$4m+XTbmiyoxBqg6qsMfCy+sOTjRoWHt01Udqe9K7bSI',1,NULL,'default','',NULL,0,'',NULL,'','a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}',NULL,NULL,1,NULL,0,NULL,NULL,0,'');
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes`
--

DROP TABLE IF EXISTS `cache_imagesizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes`
--

LOCK TABLES `cache_imagesizes` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_imagesizes_tags`
--

DROP TABLE IF EXISTS `cache_imagesizes_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_imagesizes_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_imagesizes_tags`
--

LOCK TABLES `cache_imagesizes_tags` WRITE;
/*!40000 ALTER TABLE `cache_imagesizes_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_imagesizes_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category`
--

DROP TABLE IF EXISTS `cache_news_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_news_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category`
--

LOCK TABLES `cache_news_category` WRITE;
/*!40000 ALTER TABLE `cache_news_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_news_category_tags`
--

DROP TABLE IF EXISTS `cache_news_category_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_news_category_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_news_category_tags`
--

LOCK TABLES `cache_news_category_tags` WRITE;
/*!40000 ALTER TABLE `cache_news_category_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_news_category_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(2,'1__0_0_1_1',1727451121,'x�M�Ar\� E\�\�	�=mR�\�:�d�!Fv�`\�\�6�\�\�+⒲BzH�k�VRݭ\�uZ5\\E\�*1[#�̞]\�:\�݇Ԯ�@�����cEe��4a�oL-9\�\�+\�~\\\�$6i�Wx���\�&4V\�%\���+\�\�-$*���1\�`1�]�\�\��f;\��&%�q	i�%�\�\�\�9�\�e\�#\�JÄ+\�f,��\��\�?\�QtǼ\�37\�\�.���\�\�F��p	��P��<A�l*�\�p\�_�:\�2\0\�ǂ\�\�\�z\�\'S08\�\�\�\�\��3��');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(2,'1__0_0_1_1','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_treelist`
--

DROP TABLE IF EXISTS `cache_treelist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cache_treelist` (
  `md5hash` varchar(32) NOT NULL DEFAULT '',
  `pid` int(11) NOT NULL DEFAULT 0,
  `treelist` mediumtext DEFAULT NULL,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`md5hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_treelist`
--

LOCK TABLES `cache_treelist` WRITE;
/*!40000 ALTER TABLE `cache_treelist` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_treelist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `lastlogin` int(11) NOT NULL DEFAULT 0,
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` text DEFAULT NULL,
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` varchar(255) NOT NULL DEFAULT '',
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `uc` blob DEFAULT NULL,
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` tinytext DEFAULT NULL,
  `TSconfig` text DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_redirectPid` tinytext DEFAULT NULL,
  `felogin_forgotHash` varchar(80) DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `doktype` int(10) unsigned NOT NULL DEFAULT 0,
  `TSconfig` text DEFAULT NULL,
  `is_siteroot` smallint(6) NOT NULL DEFAULT 0,
  `php_tree_stop` smallint(6) NOT NULL DEFAULT 0,
  `url` varchar(255) NOT NULL DEFAULT '',
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `target` varchar(80) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` text DEFAULT NULL,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `description` text DEFAULT NULL,
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `abstract` text DEFAULT NULL,
  `module` varchar(255) NOT NULL DEFAULT '',
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(6) NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `l18n_cfg` smallint(6) NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `lastUpdated` int(11) NOT NULL DEFAULT 0,
  `newUntil` int(11) NOT NULL DEFAULT 0,
  `slug` varchar(2048) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(6) NOT NULL DEFAULT 0,
  `no_follow` smallint(6) NOT NULL DEFAULT 0,
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` text DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` text DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  `canonical_link` varchar(2048) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `nav_icon_set` varchar(255) NOT NULL DEFAULT '',
  `nav_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `nav_icon` int(10) unsigned DEFAULT 0,
  `thumbnail` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1718987124,1718360202,0,0,0,0,'',256,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Dengram',1,NULL,1,0,'',0,0,'Dengram Alumni 2000 Set',0,'',1,NULL,0,'',NULL,0,1718987124,NULL,'',0,'','','',0,0,0,0,0,'pagets__homepage','pagets__default',NULL,0,0,0,'/',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(2,0,1718360398,1718360361,1,0,0,0,'0',512,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Home',4,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(3,1,1718371116,1718360530,0,0,0,0,'',64,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"shortcut_mode\":\"\",\"shortcut\":\"\",\"abstract\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"target\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Home',4,NULL,0,0,'',0,3,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/home',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(4,1,1718909836,1718371103,0,0,0,0,'',128,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Membership',1,NULL,0,0,'',0,0,'Members',0,'',1,NULL,0,'',NULL,0,1718909836,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/membership',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(5,1,1718371103,1718371103,0,0,0,0,'0',192,NULL,0,0,0,0,NULL,0,'',0,0,0,0,1,0,31,27,0,'Projects',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/projects',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(6,1,1718371103,1718371103,0,0,0,0,'0',224,NULL,0,0,0,0,NULL,0,'',0,0,0,0,1,0,31,27,0,'Contact us',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/contact-us',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(7,0,1718380464,1718380461,0,0,0,0,'0',128,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,1,31,31,0,'engram_alumni',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(8,1,1718882455,1718882450,0,0,0,0,'0',480,NULL,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,'Teams',254,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',0,0,0,0,0,'','',NULL,0,0,0,'/teams',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(9,1,1718883142,1718883088,1,0,0,0,'',144,NULL,0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Member',1,NULL,0,0,'',0,0,'',0,'',0,NULL,0,'',NULL,0,0,NULL,'',0,'','','',1,0,0,0,0,'','',NULL,0,0,0,'/member',0,'',0,0,'',NULL,0,'',NULL,0,'summary','',0.5,'','','',0,0),
(10,4,1718959624,1718883266,0,0,0,0,'',256,'',0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'Set',1,'',0,0,'',0,0,'',0,'',1,'',0,'','',0,1718960033,'','',0,'','','',1,0,0,0,0,'','','',0,0,0,'/membership/set',0,'',0,0,'','',0,'','',0,'summary','',0.5,'','','',0,0),
(11,4,1718972088,1718967106,0,0,0,0,'',128,'',0,0,0,0,NULL,0,'{\"doktype\":\"\",\"title\":\"\",\"slug\":\"\",\"nav_title\":\"\",\"subtitle\":\"\",\"seo_title\":\"\",\"description\":\"\",\"no_index\":\"\",\"no_follow\":\"\",\"canonical_link\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"og_title\":\"\",\"og_description\":\"\",\"og_image\":\"\",\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":\"\",\"twitter_card\":\"\",\"abstract\":\"\",\"keywords\":\"\",\"author\":\"\",\"author_email\":\"\",\"lastUpdated\":\"\",\"layout\":\"\",\"newUntil\":\"\",\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"content_from_pid\":\"\",\"target\":\"\",\"cache_timeout\":\"\",\"cache_tags\":\"\",\"is_siteroot\":\"\",\"no_search\":\"\",\"php_tree_stop\":\"\",\"module\":\"\",\"media\":\"\",\"tsconfig_includes\":\"\",\"TSconfig\":\"\",\"l18n_cfg\":\"\",\"hidden\":\"\",\"nav_hide\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"extendToSubpages\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,1,0,31,27,0,'List',1,'',0,0,'',0,0,'',0,'',1,'',0,'','',0,1718972088,'','',0,'','','',1,0,0,0,0,'','','',0,0,0,'/membership/list',0,'',0,0,'','',0,'','',0,'summary','',0.5,'','','',0,0);
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext NOT NULL,
  `items` int(11) NOT NULL DEFAULT 0,
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(100) NOT NULL DEFAULT '0',
  `images` int(10) unsigned DEFAULT 0,
  `single_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(11) NOT NULL DEFAULT 0,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `import` (`import_id`,`import_source`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
INSERT INTO `sys_category` VALUES
(1,1,1718884991,1718884991,0,0,0,0,256,'',0,0,NULL,0,'',0,0,0,0,'members',0,0,'0',0,0,0,'','','','','','','members'),
(2,1,1718885062,1718885062,0,0,0,0,128,'',0,0,NULL,0,'',0,0,0,0,'2015',0,1,'0',0,0,0,'','','','','','','2015');
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
INSERT INTO `sys_category_record_mm` VALUES
(1,11,'tt_content','categories',0,1),
(2,1,'tx_news_domain_model_news','categories',0,1),
(2,2,'tx_news_domain_model_news','categories',0,1);
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `missing` smallint(6) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `type` varchar(10) NOT NULL DEFAULT '',
  `metadata` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `size` bigint(20) unsigned NOT NULL DEFAULT 0,
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1718375751,1718375751,0,0,'2',0,'/_assets/cf189c3d292907e46519306a8559b421/Images/logo_pp.png','f78eb25086bf292f56854a6ed14af83e2b9f7c55','819882f84b84f7557f2e21c39f0ff3130ddc2de9','png','image/png','logo_pp.png','8ab84af67098812be520339dde06da6d9d801b11',1771,1718369749,1718369749),
(2,0,1718626881,1718626881,0,1,'2',0,'/dengram/large-pic.jpg','3e8c69d70b05e0f554154509c5866db000f23ce8','839d64b5058dff089f26185a295573091fb700ba','jpg','image/jpeg','large-pic.jpg','ab92dd046888c7c53519c070ff8218d9c9fc84bc',149883,1718626881,1718626881),
(3,0,1718638261,1718638261,0,1,'2',0,'/dengram/welcome-slider/large-pic.jpg','ca61bd196af88b501833b3915b84dbbba6ae7884','4d19f945de0f779222615e5a96c0ad3a031832ba','jpg','image/jpeg','large-pic.jpg','ab92dd046888c7c53519c070ff8218d9c9fc84bc',149883,1718638261,1718638261),
(4,0,1718638622,1718638622,0,1,'2',0,'/dengram/welcome-slider/1.jpg','d99f5160e19a8a4f49e55a045bdfd53f1988f1bc','4d19f945de0f779222615e5a96c0ad3a031832ba','jpg','image/jpeg','1.jpg','17810e3b5e8c2d2598d96dec93690890bd7f2245',75016,1718638622,1718638622),
(5,0,1718638622,1718638622,0,1,'2',0,'/dengram/welcome-slider/2.jpg','1def4192679dc91864564a79f1e8ae3517ab83a8','4d19f945de0f779222615e5a96c0ad3a031832ba','jpg','image/jpeg','2.jpg','c51f33ad4f996d1f07f04c6310c52589b8a1b3b3',76523,1718638622,1718638622),
(6,0,1718638622,1718638622,0,1,'2',0,'/dengram/welcome-slider/3.jpg','d021227eeb837c77d053e74ab5be63dfbc89f1ff','4d19f945de0f779222615e5a96c0ad3a031832ba','jpg','image/jpeg','3.jpg','b83ad3b768dfdc96e2325d8de11f11cc0537ea30',86887,1718638622,1718638622),
(7,0,1718716531,1718716531,0,1,'2',0,'/dengram/banner/1.jpg','5892f0855e26e9aa66eabb59b9239b7f08bb31d0','af47e63c0b10aecbf76ea11e2ebb0411a5283e92','jpg','image/jpeg','1.jpg','61ed5bbe994388375f24d1f0cfc188b093a53d99',1329376,1718369324,1718369324),
(8,0,1718884619,1718884619,0,1,'2',0,'/dengram/old-boys/tm1.jpeg','c9e65b4498a017f68b2a9ac15bc3f10ffd8ba4b1','a84cece8b5b8640d406339a00571e5529d1e9704','jpeg','image/jpeg','tm1.jpeg','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84',132717,1718884619,1718884619),
(9,0,1718905420,1718905420,0,1,'2',0,'/dengram/old-boys/tm2.jpeg','a92f1b8a44f65bb070b3cd7ba012986007d926cb','a84cece8b5b8640d406339a00571e5529d1e9704','jpeg','image/jpeg','tm2.jpeg','9d37c02b4155706be83e37272c4038291260145c',88790,1718905420,1718905420),
(10,0,1718963391,1718963391,0,1,'2',0,'/dengram/banner/ptn-1.png','0625a2614360b549555b36ebd08162c1fe82e756','af47e63c0b10aecbf76ea11e2ebb0411a5283e92','png','image/png','ptn-1.png','aa4158d94af0734c9c1de91b3cb54bf4b2932d0d',1792,1718963391,1718963391);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(11) NOT NULL DEFAULT 0,
  `folder_identifier` varchar(255) NOT NULL DEFAULT '',
  `recursive` smallint(6) NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `file` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `fal_filelist` (`l10n_parent`,`sys_language_uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1718375751,1718375751,0,0,NULL,0,'',0,0,0,0,1,NULL,364,64,NULL,NULL,0),
(2,0,1718626881,1718626881,0,0,NULL,0,'',0,0,0,0,2,NULL,420,535,NULL,NULL,0),
(3,0,1718638261,1718638261,0,0,NULL,0,'',0,0,0,0,3,NULL,420,535,NULL,NULL,0),
(4,0,1718638622,1718638622,0,0,NULL,0,'',0,0,0,0,4,NULL,307,384,NULL,NULL,0),
(5,0,1718638622,1718638622,0,0,NULL,0,'',0,0,0,0,5,NULL,307,384,NULL,NULL,0),
(6,0,1718638622,1718638622,0,0,NULL,0,'',0,0,0,0,6,NULL,307,384,NULL,NULL,0),
(7,0,1718716531,1718716531,0,0,NULL,0,'',0,0,0,0,7,NULL,1920,1080,NULL,NULL,0),
(8,0,1718884619,1718884619,0,0,NULL,0,'',0,0,0,0,8,NULL,720,860,NULL,NULL,0),
(9,0,1718905420,1718905420,0,0,NULL,0,'',0,0,0,0,9,NULL,720,860,NULL,NULL,0),
(10,0,1718963391,1718963391,0,0,NULL,0,'',0,0,0,0,10,NULL,265,259,NULL,NULL,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
INSERT INTO `sys_file_processedfile` VALUES
(1,1718986829,1718626881,1,2,'/_processed_/e/c/csm_large-pic_13edcb9dae.jpg','csm_large-pic_13edcb9dae.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','13edcb9dae',32,32),
(2,1718626881,1718626881,1,2,'/_processed_/e/c/csm_large-pic_c6de061eab.jpg','csm_large-pic_c6de061eab.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','c6de061eab',90,115),
(3,1718626895,1718626891,1,2,'/_processed_/e/c/csm_large-pic_cd9c2004a1.jpg','csm_large-pic_cd9c2004a1.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','cd9c2004a1',118,150),
(4,1718626892,1718626891,1,2,'/_processed_/e/c/csm_large-pic_8dcc51aaad.jpg','csm_large-pic_8dcc51aaad.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','8dcc51aaad',35,45),
(5,1718626933,1718626933,1,2,'/_processed_/e/c/preview_large-pic_45c29b036d.jpg','preview_large-pic_45c29b036d.jpg','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.Preview','45c29b036d',50,64),
(6,1718628496,1718628496,1,2,'',NULL,'','a:3:{s:5:\"width\";i:420;s:6:\"height\";i:535;s:4:\"crop\";N;}','98aa69d915b122663f674334a5af55753b5250fc','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','1c797465ea',0,0),
(11,1718963289,1718638622,1,5,'/_processed_/7/2/csm_2_fd7c87a58c.jpg','csm_2_fd7c87a58c.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','c51f33ad4f996d1f07f04c6310c52589b8a1b3b3','Image.CropScaleMask','fd7c87a58c',32,32),
(12,1718638622,1718638622,1,5,'/_processed_/7/2/csm_2_3ea8e504f6.jpg','csm_2_3ea8e504f6.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','c51f33ad4f996d1f07f04c6310c52589b8a1b3b3','Image.CropScaleMask','3ea8e504f6',92,115),
(13,1718963289,1718638622,1,6,'/_processed_/1/f/csm_3_8729fe6e5e.jpg','csm_3_8729fe6e5e.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','b83ad3b768dfdc96e2325d8de11f11cc0537ea30','Image.CropScaleMask','8729fe6e5e',32,32),
(14,1718638622,1718638622,1,6,'/_processed_/1/f/csm_3_03048e6eb1.jpg','csm_3_03048e6eb1.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','b83ad3b768dfdc96e2325d8de11f11cc0537ea30','Image.CropScaleMask','03048e6eb1',92,115),
(15,1718963289,1718700604,1,4,'/_processed_/1/4/csm_1_2e06d4de56.jpg','csm_1_2e06d4de56.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','17810e3b5e8c2d2598d96dec93690890bd7f2245','Image.CropScaleMask','2e06d4de56',32,32),
(16,1718700604,1718700604,1,4,'/_processed_/1/4/csm_1_bfdfde4ef1.jpg','csm_1_bfdfde4ef1.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','17810e3b5e8c2d2598d96dec93690890bd7f2245','Image.CropScaleMask','bfdfde4ef1',92,115),
(17,1718963289,1718700604,1,3,'/_processed_/2/5/csm_large-pic_e415006e71.jpg','csm_large-pic_e415006e71.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','e415006e71',32,32),
(18,1718700604,1718700604,1,3,'/_processed_/2/5/csm_large-pic_67bea2fc21.jpg','csm_large-pic_67bea2fc21.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','ab92dd046888c7c53519c070ff8218d9c9fc84bc','Image.CropScaleMask','67bea2fc21',92,115),
(19,1718986808,1718716531,1,7,'/_processed_/2/9/csm_1_2e382456d7.jpg','csm_1_2e382456d7.jpg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','2e382456d7',32,32),
(20,1718716531,1718716531,1,7,'/_processed_/2/9/csm_1_35c40a49af.jpg','csm_1_35c40a49af.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','35c40a49af',166,93),
(21,1718909548,1718716535,1,7,'/_processed_/2/9/csm_1_63a87aef62.jpg','csm_1_63a87aef62.jpg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','63a87aef62',267,150),
(22,1718716535,1718716535,1,7,'/_processed_/2/9/csm_1_97f3c293ef.jpg','csm_1_97f3c293ef.jpg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','97f3c293ef',80,45),
(23,1718716587,1718716587,1,7,'/_processed_/2/9/csm_1_ec2e2b5c48.jpg','csm_1_ec2e2b5c48.jpg',NULL,'a:12:{s:5:\"width\";s:5:\"1280c\";s:6:\"height\";s:4:\"720c\";s:13:\"fileExtension\";s:0:\"\";s:8:\"maxWidth\";i:0;s:9:\"maxHeight\";i:0;s:8:\"minWidth\";i:0;s:9:\"minHeight\";i:0;s:7:\"noScale\";s:0:\"\";s:6:\"sample\";b:0;s:20:\"additionalParameters\";s:0:\"\";s:5:\"frame\";i:0;s:4:\"crop\";N;}','6e2ad084a4d589f6e7903215f548314135abd682','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','ec2e2b5c48',1280,720),
(24,1718716719,1718716719,1,7,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','61ed5bbe994388375f24d1f0cfc188b093a53d99','Image.CropScaleMask','fc34c11c52',0,0),
(25,1718987316,1718884619,1,8,'/_processed_/6/f/csm_tm1_ca03c7346d.jpeg','csm_tm1_ca03c7346d.jpeg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','ca03c7346d',32,32),
(26,1718884619,1718884619,1,8,'/_processed_/6/f/csm_tm1_1531a7ef26.jpeg','csm_tm1_1531a7ef26.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','1531a7ef26',96,115),
(27,1718884652,1718884625,1,8,'/_processed_/6/f/csm_tm1_72ab5c806a.jpeg','csm_tm1_72ab5c806a.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','72ab5c806a',126,150),
(28,1718884625,1718884625,1,8,'/_processed_/6/f/csm_tm1_6d1914d716.jpeg','csm_tm1_6d1914d716.jpeg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','6d1914d716',38,45),
(29,1718885677,1718885677,1,8,'/_processed_/6/f/csm_tm1_1c3eda2b6b.jpeg','csm_tm1_1c3eda2b6b.jpeg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:100;s:9:\"maxHeight\";i:100;s:4:\"crop\";N;}','1de85feb3e25752eaaeafd731583414ea1d5b62a','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','1c3eda2b6b',84,100),
(30,1718904666,1718904666,1,8,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','446d41e0e3',0,0),
(31,1718987316,1718905420,1,9,'/_processed_/2/6/csm_tm2_072c7efc6d.jpeg','csm_tm2_072c7efc6d.jpeg','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','072c7efc6d',32,32),
(32,1718905421,1718905420,1,9,'/_processed_/2/6/csm_tm2_83e19f87e5.jpeg','csm_tm2_83e19f87e5.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','83e19f87e5',96,115),
(33,1718905431,1718905428,1,9,'/_processed_/2/6/csm_tm2_04945fc2a2.jpeg','csm_tm2_04945fc2a2.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";i:150;s:4:\"crop\";N;}','cfe93cbb07d0cfbe7800b799777ad2e70305dbab','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','04945fc2a2',126,150),
(34,1718905428,1718905428,1,9,'/_processed_/2/6/csm_tm2_cfe5eaf2b4.jpeg','csm_tm2_cfe5eaf2b4.jpeg','','a:3:{s:8:\"maxWidth\";i:145;s:9:\"maxHeight\";i:45;s:6:\"height\";s:3:\"45m\";}','99641ee1e111db8018e526d3105ad5631f8f88a4','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','cfe5eaf2b4',38,45),
(35,1718908399,1718908399,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','24f48d5b4de7d99b7144e6559156976855e74b5d','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','68bb90add1',0,0),
(36,1718954617,1718954617,1,9,'/_processed_/2/6/csm_tm2_1fa9d02768.jpeg','csm_tm2_1fa9d02768.jpeg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:100;s:9:\"maxHeight\";i:100;s:4:\"crop\";N;}','1de85feb3e25752eaaeafd731583414ea1d5b62a','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','1fa9d02768',84,100),
(37,1718959466,1718959466,1,8,'/_processed_/6/f/preview_tm1_1b80311337.jpeg','preview_tm1_1b80311337.jpeg','','a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.Preview','1b80311337',126,150),
(38,1718960044,1718960044,1,8,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1200;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','1495e2df9df1b6ca7f74752327ebb626a23b3676','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','8ccbd29826',0,0),
(39,1718960044,1718960044,1,8,'/_processed_/6/f/csm_tm1_89b4911a0f.jpeg','csm_tm1_89b4911a0f.jpeg',NULL,'a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:282;s:9:\"maxHeight\";s:0:\"\";s:4:\"crop\";N;}','46a68eaf10fc51ac2a48086b40820bff1e0b1126','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','89b4911a0f',282,337),
(40,1718963391,1718963391,1,10,'/_processed_/e/7/preview_ptn-1_ff15fdbc0c.png','preview_ptn-1_ff15fdbc0c.png','','a:2:{s:5:\"width\";i:64;s:6:\"height\";i:64;}','551dfa8957f1a04693c61acf34bc959a1ca971c4','aa4158d94af0734c9c1de91b3cb54bf4b2932d0d','Image.Preview','ff15fdbc0c',64,63),
(41,1718986808,1718963401,1,10,'/_processed_/e/7/csm_ptn-1_b756421f10.png','csm_ptn-1_b756421f10.png','','a:2:{s:5:\"width\";s:3:\"32c\";s:6:\"height\";s:3:\"32c\";}','48ec22f851d7822181aeed9649f97929e5f0c410','aa4158d94af0734c9c1de91b3cb54bf4b2932d0d','Image.CropScaleMask','b756421f10',32,32),
(42,1718963402,1718963401,1,10,'/_processed_/e/7/csm_ptn-1_55822bd789.png','csm_ptn-1_55822bd789.png','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:166;s:9:\"maxHeight\";i:115;s:4:\"crop\";N;}','42bbd46565440d020e85026168e5aeb9653d29fa','aa4158d94af0734c9c1de91b3cb54bf4b2932d0d','Image.CropScaleMask','55822bd789',118,115),
(43,1718964188,1718964188,1,8,'/_processed_/6/f/csm_tm1_cc0d6aa5b4.jpeg','csm_tm1_cc0d6aa5b4.jpeg',NULL,'a:7:{s:5:\"width\";s:5:\"411px\";s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','dc48226e58ec9aea47ef02b17abbf4a1eccce1ae','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','cc0d6aa5b4',411,491),
(44,1718964990,1718964990,1,8,'/_processed_/6/f/csm_tm1_0a66cde7e7.jpeg','csm_tm1_0a66cde7e7.jpeg',NULL,'a:7:{s:5:\"width\";s:5:\"211px\";s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3e64507f35a60e748d13b0d6e9b9539a1ed7808c','0e11e83e0f2adf075fe4fbf7c1e651dc92d2ab84','Image.CropScaleMask','0a66cde7e7',211,253),
(45,1718965142,1718965142,1,9,'/_processed_/2/6/csm_tm2_608f3e3ae6.jpeg','csm_tm2_608f3e3ae6.jpeg',NULL,'a:7:{s:5:\"width\";s:5:\"211px\";s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";N;s:9:\"maxHeight\";N;s:4:\"crop\";N;}','3e64507f35a60e748d13b0d6e9b9539a1ed7808c','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','608f3e3ae6',211,253),
(46,1718986851,1718905420,1,9,'',NULL,'','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:1000;s:9:\"maxHeight\";i:1000;s:4:\"crop\";N;}','1097b19f7c94bc1bdd2bf43bfc22198c30890d2e','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','f1acfba51d',720,860),
(47,1718986851,1718986851,1,9,'/_processed_/2/6/csm_tm2_827a9edb8e.jpeg','csm_tm2_827a9edb8e.jpeg','','a:7:{s:5:\"width\";N;s:6:\"height\";N;s:8:\"minWidth\";N;s:9:\"minHeight\";N;s:8:\"maxWidth\";i:300;s:9:\"maxHeight\";i:300;s:4:\"crop\";N;}','e239fcbae08ee546b841850592062fe370de3336','9d37c02b4155706be83e37272c4038291260145c','Image.CropScaleMask','827a9edb8e',251,300),
(48,1718987285,1718987285,1,9,'/_processed_/2/6/preview_tm2_fd4c17879c.jpeg','preview_tm2_fd4c17879c.jpeg','','a:2:{s:5:\"width\";i:150;s:6:\"height\";i:150;}','55d97d4e532f03dbc8a5053eac06a25a43ca2e20','9d37c02b4155706be83e37272c4038291260145c','Image.Preview','fd4c17879c',126,150);
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `description` text DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `crop` varchar(4000) NOT NULL DEFAULT '',
  `autoplay` smallint(6) NOT NULL DEFAULT 0,
  `showinpreview` smallint(6) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
INSERT INTO `sys_file_reference` VALUES
(1,1,1718627127,1718626917,1,0,0,0,NULL,'',0,0,0,0,2,4,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(2,1,1718627198,1718627198,0,0,0,0,NULL,'',0,0,0,0,2,6,'tt_content','image',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(3,1,1718987124,1718716540,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,7,1,'pages','media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(4,8,1718963138,1718884662,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,8,1,'tx_news_domain_model_news','fal_media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,1),
(5,8,1718908377,1718905440,1,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,9,2,'tx_news_domain_model_news','fal_media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(6,8,1718908395,1718908377,0,0,0,0,NULL,'{\"showinpreview\":\"\",\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,9,2,'tx_news_domain_model_news','fal_media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,1),
(7,4,1718909836,1718909582,0,0,0,0,NULL,'{\"alternative\":\"\",\"description\":\"\",\"link\":\"\",\"title\":\"\",\"crop\":\"\",\"uid_local\":\"\",\"hidden\":\"\",\"sys_language_uid\":\"\"}',0,0,0,0,7,4,'pages','media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(8,10,1718959624,1718959624,0,0,0,0,NULL,'',0,0,0,0,7,10,'pages','media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(9,11,1718972088,1718972088,0,0,0,0,NULL,'',0,0,0,0,7,11,'pages','media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(10,8,1718987063,1718987021,1,0,0,0,NULL,'',0,0,0,0,9,3,'tx_news_domain_model_news','fal_media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,0),
(11,8,1718987063,1718987063,0,0,0,0,NULL,'',0,0,0,0,9,3,'tx_news_domain_model_news','fal_media',1,NULL,NULL,NULL,'','{\"default\":{\"cropArea\":{\"x\":0,\"y\":0,\"width\":1,\"height\":1},\"selectedRatio\":\"NaN\",\"focusArea\":null}}',0,1);
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `driver` tinytext DEFAULT NULL,
  `configuration` text DEFAULT NULL,
  `is_default` smallint(6) NOT NULL DEFAULT 0,
  `is_browsable` smallint(6) NOT NULL DEFAULT 0,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `is_writable` smallint(6) NOT NULL DEFAULT 0,
  `is_online` smallint(6) NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(6) NOT NULL DEFAULT 1,
  `processingfolder` tinytext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1718360207,1718360207,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.','fileadmin','Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',1,1,1,1,1,1,NULL);
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=165 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1718360202,1,'BE',1,0,1,'pages','{\"uid\":1,\"pid\":0,\"tstamp\":1718360202,\"crdate\":1718360202,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"dengram\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$cd28e0699052bc575954c55b5712e068:e175f7045d7ccbfb26ffcf279422c2e5'),
(2,1718360202,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$b0ad1265018512caa61582558a578e3b:e175f7045d7ccbfb26ffcf279422c2e5'),
(3,1718360205,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$54b88ae02522e97265a3c1788c435557:e175f7045d7ccbfb26ffcf279422c2e5'),
(4,1718360224,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"is_siteroot\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"is_siteroot\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$3b6e7587372c3dab70fb8106111a0c83:e175f7045d7ccbfb26ffcf279422c2e5'),
(5,1718360361,1,'BE',1,0,2,'pages','{\"uid\":2,\"pid\":0,\"tstamp\":1718360361,\"crdate\":1718360361,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":512,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"doktype\":4,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$d108264a35f5d84f4a353020caf1938c:f11830df10b4b0bca2db34810c2241b3'),
(6,1718360361,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$92cbe5d9f8962586c9e821c55d13ba82:f11830df10b4b0bca2db34810c2241b3'),
(7,1718360364,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7c415b19b2d23b2f625c75740c5bfe93:f11830df10b4b0bca2db34810c2241b3'),
(8,1718360398,4,'BE',1,0,2,'pages',NULL,0,'0400$5a94ba9da4d5b3b93cb807ce3f8e1b0d:f11830df10b4b0bca2db34810c2241b3'),
(9,1718360530,1,'BE',1,0,3,'pages','{\"uid\":3,\"pid\":1,\"tstamp\":1718360530,\"crdate\":1718360530,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":256,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Home\",\"doktype\":4,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/home\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$d90b76e4b2fab63207b04efd102428be:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(10,1718360535,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$c7eb7768226ea5470cf532ec7a93f71c:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(11,1718360559,2,'BE',1,0,3,'pages','{\"oldRecord\":{\"shortcut_mode\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"shortcut_mode\":\"3\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"shortcut_mode\\\":\\\"\\\",\\\"shortcut\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$40641af0d378ce3afa6c8d91e6a6a8d8:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(12,1718362673,1,'BE',1,0,1,'sys_template','{\"uid\":1,\"pid\":1,\"tstamp\":1718362673,\"crdate\":1718362673,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":\"\",\"t3_origuid\":0,\"title\":\"dengram package\",\"root\":0,\"clear\":3,\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript\",\"constants\":\"\",\"config\":\"\",\"basedOn\":\"\",\"includeStaticAfterBasedOn\":0,\"static_file_mode\":0,\"tx_impexp_origuid\":0}',0,'0400$1ed200bb69b7874323a475d1ba768f45:35af6288617af54964e77af08c30949a'),
(13,1718362706,1,'BE',1,0,1,'tt_content','{\"uid\":1,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718362706,\"crdate\":1718362706,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"text\",\"header\":\"Welcome\",\"header_position\":\"\",\"bodytext\":\"<p>Hello world<\\/p>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$ead68a5e13a9c4bb77487baa08bb69c0:7fa2c035f26826fe83eeecaaeddc4d40'),
(14,1718362744,4,'BE',1,0,1,'tt_content',NULL,0,'0400$6b0dc2ecf91c345f39997abfc8be85a1:7fa2c035f26826fe83eeecaaeddc4d40'),
(15,1718370759,1,'BE',1,0,2,'tt_content','{\"uid\":2,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718370759,\"crdate\":1718370759,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"html\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<!-- INNER PAGE BANNER -->\\r\\n            <div class=\\\"wt-bnr-inr overlay-wraper bg-center\\\"  style=\\\"background-image:url(images\\/banner\\/1.jpg);\\\">\\r\\n            \\t<div class=\\\"overlay-main bg-black opacity-07\\\"><\\/div>\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"wt-bnr-inr-entry\\\">\\r\\n                    \\t<div class=\\\"banner-title-outer\\\">\\r\\n                        \\t<div class=\\\"banner-title-name\\\">\\r\\n                        \\t\\t<h2 class=\\\"text-white\\\">About Us<\\/h2>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <!-- BREADCRUMB ROW -->                            \\r\\n                        \\r\\n                            <div>\\r\\n                                <ul class=\\\"wt-breadcrumb breadcrumb-style-2\\\">\\r\\n                                    <li><a href=\\\"index.html\\\">Home<\\/a><\\/li>\\r\\n                                    <li>About 1<\\/li>\\r\\n                                <\\/ul>\\r\\n                            <\\/div>\\r\\n                        \\r\\n                        <!-- BREADCRUMB ROW END -->                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>\\r\\n            <!-- INNER PAGE BANNER END -->\\r\\n            \\r\\n            <!-- WELCOME SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-white\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                        \\t<div class=\\\"col-lg-7 col-md-12 m-b30\\\">\\r\\n                            \\t<div class=\\\"welcome-carousel-outer m-b60\\\">\\r\\n                                \\t<div class=\\\"welcome-bg-block clearfix\\\">\\r\\n                                        <div class=\\\"welcome-carousel-1 \\\">\\r\\n                                            <div class=\\\"owl-carousel home-carousel-1 owl-btn-bottom-left\\\">\\r\\n                                                <!-- COLUMNS 1 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/1.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 2 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/2.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 3 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"owl-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/3.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 4 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/4.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 5 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/5.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                           <\\/div>\\r\\n                                        <\\/div>                                 \\r\\n                                   <\\/div>\\r\\n                               <\\/div>\\r\\n                            <\\/div>\\r\\n                    \\t\\t<div class=\\\"col-lg-5 col-md-12 m-b30\\\">\\r\\n                                <!-- TITLE START -->\\r\\n                                <div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to Dengram Alumni<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\\r\\n                                <!-- TITLE END -->                            \\r\\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\\r\\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n                                 <a href=\\\"project-detail.html\\\" class=\\\"site-button m-t15 m-b15\\\">Read More<\\/a>\\r\\n                            <\\/div>                            \\r\\n                        <\\/div>\\r\\n                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>   \\r\\n            <!-- WELCOME  SECTION END --> \\r\\n            \\r\\n            <!-- WHAT WE DO SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-gray\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">what you prefer<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>What we do<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END -->\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect  v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-sketch\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Planning<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>                          \\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                                <div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">interior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window-5\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Exterior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-plant\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Decoration<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                 <\\/div>\\r\\n                            <\\/div>                          \\r\\n                        <\\/div>                                \\r\\n                    <\\/div>\\r\\n                <\\/div>  \\r\\n            <\\/div>   \\r\\n            <!-- WHAT WE DO  SECTION END --> \\r\\n            \\r\\n            <!-- OUR TEAM START -->\\r\\n            <div class=\\\"section-full small-device p-t80 p-b50 bg-white\\\">\\r\\n\\t\\t\\t\\t<div class=\\\"container\\\">\\r\\n\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Our Best Team<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>Our Team<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END --> \\r\\n     \\r\\n                    <!-- IMAGE CAROUSEL START -->\\r\\n                    <div class=\\\"row d-flex justify-content-center\\\">\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                        <h4>Jack Semper<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic1.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                        <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Philip Wilson<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic2.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Amanda Rich<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic3.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                    <\\/div>\\r\\n\\r\\n                <\\/div>\\r\\n                \\r\\n             <\\/div>   \\r\\n            <!-- OUR TEAM END -->\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$afedb5029e3e35fcce21e262c1a0d3ad:01dbc21fdb1263685b9147b3b1596ea8'),
(16,1718371103,1,'BE',1,0,4,'pages','{\"uid\":4,\"pid\":1,\"tstamp\":1718371103,\"crdate\":1718371103,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Membership\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/membership\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$be66fe4dccf2c2fc519eff3864c15777:412add0b3eb6ec8f1cb6710aea92e21e'),
(17,1718371103,1,'BE',1,0,5,'pages','{\"uid\":5,\"pid\":1,\"tstamp\":1718371103,\"crdate\":1718371103,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":192,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Projects\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/projects\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$be66fe4dccf2c2fc519eff3864c15777:7ef5a4e3e11db8ac3fea4d7a75468161'),
(18,1718371103,1,'BE',1,0,6,'pages','{\"uid\":6,\"pid\":1,\"tstamp\":1718371103,\"crdate\":1718371103,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":224,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Contact us\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/contact-us\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$be66fe4dccf2c2fc519eff3864c15777:c75354c439a48dbde16b03ac553a080d'),
(19,1718371116,3,'BE',1,0,3,'pages','{\"oldPageId\":1,\"newPageId\":1,\"oldData\":{\"header\":\"Home\",\"pid\":1,\"event_pid\":3,\"t3ver_state\":0},\"newData\":{\"tstamp\":1718371116,\"pid\":1,\"sorting\":64}}',0,'0400$af56219ac8ea86fbe3375557b5015c39:fe15eeb7d49e64e2cea91ab53fcf0db1'),
(20,1718375469,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"bodytext\":\"<!-- INNER PAGE BANNER -->\\r\\n            <div class=\\\"wt-bnr-inr overlay-wraper bg-center\\\"  style=\\\"background-image:url(images\\/banner\\/1.jpg);\\\">\\r\\n            \\t<div class=\\\"overlay-main bg-black opacity-07\\\"><\\/div>\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"wt-bnr-inr-entry\\\">\\r\\n                    \\t<div class=\\\"banner-title-outer\\\">\\r\\n                        \\t<div class=\\\"banner-title-name\\\">\\r\\n                        \\t\\t<h2 class=\\\"text-white\\\">About Us<\\/h2>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <!-- BREADCRUMB ROW -->                            \\r\\n                        \\r\\n                            <div>\\r\\n                                <ul class=\\\"wt-breadcrumb breadcrumb-style-2\\\">\\r\\n                                    <li><a href=\\\"index.html\\\">Home<\\/a><\\/li>\\r\\n                                    <li>About 1<\\/li>\\r\\n                                <\\/ul>\\r\\n                            <\\/div>\\r\\n                        \\r\\n                        <!-- BREADCRUMB ROW END -->                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>\\r\\n            <!-- INNER PAGE BANNER END -->\\r\\n            \\r\\n            <!-- WELCOME SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-white\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                        \\t<div class=\\\"col-lg-7 col-md-12 m-b30\\\">\\r\\n                            \\t<div class=\\\"welcome-carousel-outer m-b60\\\">\\r\\n                                \\t<div class=\\\"welcome-bg-block clearfix\\\">\\r\\n                                        <div class=\\\"welcome-carousel-1 \\\">\\r\\n                                            <div class=\\\"owl-carousel home-carousel-1 owl-btn-bottom-left\\\">\\r\\n                                                <!-- COLUMNS 1 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/1.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 2 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/2.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 3 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"owl-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/3.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 4 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/4.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 5 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/5.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                           <\\/div>\\r\\n                                        <\\/div>                                 \\r\\n                                   <\\/div>\\r\\n                               <\\/div>\\r\\n                            <\\/div>\\r\\n                    \\t\\t<div class=\\\"col-lg-5 col-md-12 m-b30\\\">\\r\\n                                <!-- TITLE START -->\\r\\n                                <div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to Dengram Alumni<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\\r\\n                                <!-- TITLE END -->                            \\r\\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\\r\\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n                                 <a href=\\\"project-detail.html\\\" class=\\\"site-button m-t15 m-b15\\\">Read More<\\/a>\\r\\n                            <\\/div>                            \\r\\n                        <\\/div>\\r\\n                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>   \\r\\n            <!-- WELCOME  SECTION END --> \\r\\n            \\r\\n            <!-- WHAT WE DO SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-gray\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">what you prefer<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>What we do<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END -->\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect  v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-sketch\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Planning<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>                          \\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                                <div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">interior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window-5\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Exterior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-plant\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Decoration<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                 <\\/div>\\r\\n                            <\\/div>                          \\r\\n                        <\\/div>                                \\r\\n                    <\\/div>\\r\\n                <\\/div>  \\r\\n            <\\/div>   \\r\\n            <!-- WHAT WE DO  SECTION END --> \\r\\n            \\r\\n            <!-- OUR TEAM START -->\\r\\n            <div class=\\\"section-full small-device p-t80 p-b50 bg-white\\\">\\r\\n\\t\\t\\t\\t<div class=\\\"container\\\">\\r\\n\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Our Best Team<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>Our Team<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END --> \\r\\n     \\r\\n                    <!-- IMAGE CAROUSEL START -->\\r\\n                    <div class=\\\"row d-flex justify-content-center\\\">\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                        <h4>Jack Semper<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic1.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                        <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Philip Wilson<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic2.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Amanda Rich<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic3.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                    <\\/div>\\r\\n\\r\\n                <\\/div>\\r\\n                \\r\\n             <\\/div>   \\r\\n            <!-- OUR TEAM END -->\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<!-- INNER PAGE BANNER -->\\r\\n            <div class=\\\"wt-bnr-inr overlay-wraper bg-center\\\"  style=\\\"background-image:url(images\\/banner\\/1.jpg);\\\">\\r\\n            \\t<div class=\\\"overlay-main bg-black opacity-07\\\"><\\/div>\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"wt-bnr-inr-entry\\\">\\r\\n                    \\t<div class=\\\"banner-title-outer\\\">\\r\\n                        \\t<div class=\\\"banner-title-name\\\">\\r\\n                        \\t\\t<h2 class=\\\"text-white\\\">Welcome<\\/h2>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <!-- BREADCRUMB ROW -->                            \\r\\n                        \\r\\n                            <div>\\r\\n                                <ul class=\\\"wt-breadcrumb breadcrumb-style-2\\\">\\r\\n                                    <li><a href=\\\"index.html\\\">Home<\\/a><\\/li>\\r\\n                                    <li>About 1<\\/li>\\r\\n                                <\\/ul>\\r\\n                            <\\/div>\\r\\n                        \\r\\n                        <!-- BREADCRUMB ROW END -->                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>\\r\\n            <!-- INNER PAGE BANNER END -->\\r\\n            \\r\\n            <!-- WELCOME SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-white\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                        \\t<div class=\\\"col-lg-7 col-md-12 m-b30\\\">\\r\\n                            \\t<div class=\\\"welcome-carousel-outer m-b60\\\">\\r\\n                                \\t<div class=\\\"welcome-bg-block clearfix\\\">\\r\\n                                        <div class=\\\"welcome-carousel-1 \\\">\\r\\n                                            <div class=\\\"owl-carousel home-carousel-1 owl-btn-bottom-left\\\">\\r\\n                                                <!-- COLUMNS 1 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/1.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 2 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/2.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 3 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"owl-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/3.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 4 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/4.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 5 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/5.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                           <\\/div>\\r\\n                                        <\\/div>                                 \\r\\n                                   <\\/div>\\r\\n                               <\\/div>\\r\\n                            <\\/div>\\r\\n                    \\t\\t<div class=\\\"col-lg-5 col-md-12 m-b30\\\">\\r\\n                                <!-- TITLE START -->\\r\\n                                <div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to Dengram Alumni<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\\r\\n                                <!-- TITLE END -->                            \\r\\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\\r\\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n                                 <a href=\\\"project-detail.html\\\" class=\\\"site-button m-t15 m-b15\\\">Read More<\\/a>\\r\\n                            <\\/div>                            \\r\\n                        <\\/div>\\r\\n                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>   \\r\\n            <!-- WELCOME  SECTION END --> \\r\\n            \\r\\n            <!-- WHAT WE DO SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-gray\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">what you prefer<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>What we do<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END -->\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect  v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-sketch\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Planning<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>                          \\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                                <div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">interior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-window-5\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Exterior<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                <\\/div>\\r\\n                            <\\/div>\\r\\n                            <div class=\\\"col-lg-3 col-md-6 m-b30\\\">\\r\\n                            \\t<div class=\\\"hover-box-effect v-icon-effect\\\">\\r\\n                                    <div class=\\\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\\\">\\r\\n                                        <div class=\\\"icon-lg site-text-primary m-b20\\\">\\r\\n                                            <span class=\\\"icon-cell site-text-primary\\\"><i class=\\\"v-icon flaticon-plant\\\"><\\/i><\\/span>\\r\\n                                        <\\/div>\\r\\n                                        <div class=\\\"icon-content text-black\\\">\\r\\n                                            <h4 class=\\\"wt-tilte m-b25\\\">Decoration<\\/h4>\\r\\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.<\\/p>\\r\\n                                            <a href=\\\"project-detail.html\\\" class=\\\"site-button-link\\\" data-hover=\\\"Read More\\\">Read More<\\/a>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    \\r\\n                                 <\\/div>\\r\\n                            <\\/div>                          \\r\\n                        <\\/div>                                \\r\\n                    <\\/div>\\r\\n                <\\/div>  \\r\\n            <\\/div>   \\r\\n            <!-- WHAT WE DO  SECTION END --> \\r\\n            \\r\\n            <!-- OUR TEAM START -->\\r\\n            <div class=\\\"section-full small-device p-t80 p-b50 bg-white\\\">\\r\\n\\t\\t\\t\\t<div class=\\\"container\\\">\\r\\n\\r\\n                    <!-- TITLE START -->\\r\\n                    <div class=\\\"section-head text-center\\\">\\r\\n                        <div class=\\\"wt-separator-outer separator-center\\\">\\r\\n                            <div class=\\\"wt-separator\\\">\\r\\n                                <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Our Best Team<\\/span>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <h2>Our Team<\\/h2>\\r\\n                    <\\/div>\\r\\n                    <!-- TITLE END --> \\r\\n     \\r\\n                    <!-- IMAGE CAROUSEL START -->\\r\\n                    <div class=\\\"row d-flex justify-content-center\\\">\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                        <h4>Jack Semper<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic1.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                            <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                        <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Philip Wilson<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic2.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                        <div class=\\\"col-lg-4 col-md-6 m-b30\\\">\\r\\n                            <div class=\\\"our-team-one\\\">\\r\\n                                    <div class=\\\"team-bg\\\">\\r\\n                                    <h4>Amanda Rich<\\/h4>\\r\\n                                    <\\/div>\\r\\n                                    <div class=\\\"team-img\\\">\\r\\n                                        <img src=\\\"images\\/our-team5\\/pic3.jpg\\\" alt=\\\"\\\" \\/>\\r\\n                                        <ul class=\\\"list-unstyled\\\">\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-google\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-rss\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-facebook\\\"><\\/a><\\/li>\\r\\n                                        <li><a href=\\\"javascript:void(0);\\\" class=\\\"fa fa-twitter\\\"><\\/a><\\/li>\\r\\n                                    <\\/ul>\\r\\n                                    <\\/div>\\r\\n                            <\\/div>\\r\\n                        <\\/div>\\r\\n                    <\\/div>\\r\\n\\r\\n                <\\/div>\\r\\n                \\r\\n             <\\/div>   \\r\\n            <!-- OUR TEAM END -->\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$a35d9322f59882ebbecdb1ef06effe53:01dbc21fdb1263685b9147b3b1596ea8'),
(21,1718379910,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"root\":0},\"newRecord\":{\"root\":\"1\"}}',0,'0400$052312a470cec40910d841e6c0906e50:35af6288617af54964e77af08c30949a'),
(22,1718380149,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"static_file_mode\":0},\"newRecord\":{\"static_file_mode\":\"3\"}}',0,'0400$a13d42404632b9e855bdecc57b25affc:35af6288617af54964e77af08c30949a'),
(23,1718380461,1,'BE',1,0,7,'pages','{\"uid\":7,\"pid\":0,\"tstamp\":1718380461,\"crdate\":1718380461,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":128,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":1,\"perms_user\":31,\"perms_group\":31,\"perms_everybody\":0,\"title\":\"engram_alumni\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$8b277addd7306faa8f209a25ec44f8ec:df50bb24cbce671cf0d61f42fbbef601'),
(24,1718380461,2,'BE',1,0,7,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$d16cc7002ac589ac5931c58988b755b5:df50bb24cbce671cf0d61f42fbbef601'),
(25,1718380464,2,'BE',1,0,7,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$7edba4f02b9be87289adb7dfadc54dc4:df50bb24cbce671cf0d61f42fbbef601'),
(26,1718382332,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__homepage\"}}',0,'0400$b36210b30f7330feacd6ddc9604a112e:e175f7045d7ccbfb26ffcf279422c2e5'),
(27,1718382364,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__homepage\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$74fed01d95dfe263af3a398cbf8f4953:e175f7045d7ccbfb26ffcf279422c2e5'),
(28,1718384671,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__homepage\"}}',0,'0400$0397ebee2ebab70d42f9402eca4de4e6:e175f7045d7ccbfb26ffcf279422c2e5'),
(29,1718388959,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__homepage\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$28c66114f33026d49d086dde51ca4f4a:e175f7045d7ccbfb26ffcf279422c2e5'),
(30,1718389212,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__startpage\"}}',0,'0400$ef638e70ff12f8c6cb8f33bbfcb88365:e175f7045d7ccbfb26ffcf279422c2e5'),
(31,1718616086,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__startpage\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$cc82e8f504b8d583ef263abda83ed9f9:e175f7045d7ccbfb26ffcf279422c2e5'),
(32,1718619645,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\",\"backend_layout_next_level\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__default\",\"backend_layout_next_level\":\"pagets__default\"}}',0,'0400$72588644e8b8301d98296de677cefd6e:e175f7045d7ccbfb26ffcf279422c2e5'),
(33,1718619681,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__default\"},\"newRecord\":{\"backend_layout\":\"pagets__homepage\"}}',0,'0400$8e8d1d608adf833995d0d5d165269d1a:e175f7045d7ccbfb26ffcf279422c2e5'),
(34,1718626023,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"pagets__homepage\"},\"newRecord\":{\"backend_layout\":\"\"}}',0,'0400$8486d8c9d542499d2e3356e1153c2189:e175f7045d7ccbfb26ffcf279422c2e5'),
(35,1718626393,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"backend_layout\":\"\"},\"newRecord\":{\"backend_layout\":\"pagets__homepage\"}}',0,'0400$23dd318000d55a8503b27ffbe997752a:e175f7045d7ccbfb26ffcf279422c2e5'),
(36,1718626704,1,'BE',1,0,3,'tt_content','{\"uid\":3,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718626704,\"crdate\":1718626704,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":128,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"text\",\"header\":\"Since we  started work in 1890\",\"header_position\":\"\",\"bodytext\":\"<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n<p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n\\r\\n\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":2,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$6b11c0e513e2235b141eeb6ff38d4fe9:b92300cfb5d1d3645c9cb212a7f56c1f'),
(37,1718626713,4,'BE',1,0,2,'tt_content',NULL,0,'0400$037c70be177703aaf938a2fe9b4d5bf4:01dbc21fdb1263685b9147b3b1596ea8'),
(38,1718626917,1,'BE',1,0,4,'tt_content','{\"uid\":4,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718626917,\"crdate\":1718626917,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":64,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"image\",\"header\":\"image1\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":1,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"100\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$f45380ee28f58e1e12fa7a39bcd4b457:4d391f5ef79b8d5d10dffa8a07ca167d'),
(39,1718626917,1,'BE',1,0,1,'sys_file_reference','{\"uid\":1,\"pid\":1,\"tstamp\":1718626917,\"crdate\":1718626917,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":2,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$f45380ee28f58e1e12fa7a39bcd4b457:4cf496f597e7b095ce8b755e6cec3c0c'),
(40,1718627127,4,'BE',1,0,1,'sys_file_reference',NULL,0,'0400$5a89e56be4a1002e1eb27d24c5216cac:4cf496f597e7b095ce8b755e6cec3c0c'),
(41,1718627127,4,'BE',1,0,4,'tt_content',NULL,0,'0400$5a89e56be4a1002e1eb27d24c5216cac:4d391f5ef79b8d5d10dffa8a07ca167d'),
(42,1718627138,1,'BE',1,0,5,'tt_content','{\"uid\":5,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718627138,\"crdate\":1718627138,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":64,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"html\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<!-- WELCOME SECTION START -->\\r\\n            <div class=\\\"section-full p-t80 p-b50 bg-white\\\">\\r\\n                <div class=\\\"container\\\">\\r\\n                    <div class=\\\"section-content\\\">\\r\\n                    \\t<div class=\\\"row\\\">\\r\\n                        \\t<div class=\\\"col-lg-7 col-md-12 m-b30\\\">\\r\\n                            \\t<div class=\\\"welcome-carousel-outer m-b60\\\">\\r\\n                                \\t<div class=\\\"welcome-bg-block clearfix\\\">\\r\\n                                        <div class=\\\"welcome-carousel-1 \\\">\\r\\n                                            <div class=\\\"owl-carousel home-carousel-1 owl-btn-bottom-left\\\">\\r\\n                                                <!-- COLUMNS 1 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/1.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 2 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/2.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 3 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"owl-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/3.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 4 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/4.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                                <!-- COLUMNS 5 -->\\r\\n                                                <div class=\\\"item\\\">\\r\\n                                                    <div class=\\\"ow-img\\\">\\r\\n                                                        <a href=\\\"project-detail.html\\\"><img src=\\\"images\\/welcome-slider\\/5.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                                    <\\/div>\\r\\n                                                <\\/div>\\r\\n                                           <\\/div>\\r\\n                                        <\\/div>                                 \\r\\n                                   <\\/div>\\r\\n                               <\\/div>\\r\\n                            <\\/div>\\r\\n                    \\t\\t<div class=\\\"col-lg-5 col-md-12 m-b30\\\">\\r\\n                                <!-- TITLE START -->\\r\\n                                <div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to intoriza<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\\r\\n                                <!-- TITLE END -->                            \\r\\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\\r\\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n                                 <a href=\\\"project-detail.html\\\" class=\\\"site-button m-t15 m-b15\\\">Read More<\\/a>\\r\\n                            <\\/div>                            \\r\\n                        <\\/div>\\r\\n                        \\r\\n                    <\\/div>\\r\\n                <\\/div>\\r\\n            <\\/div>   \\r\\n            <!-- WELCOME  SECTION END --> \",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$3600eb7e02ff7ea3c9d57d31dbe17dae:c7626fc9bcba6f70beb6ebc085a400db'),
(43,1718627198,1,'BE',1,0,6,'tt_content','{\"uid\":6,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718627198,\"crdate\":1718627198,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":32,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"image\",\"header\":\"img1\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":1,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":1,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$470cfaf2f0def9c13c462dccab2c1467:c0db6803ab1ec5f70c36e2a72187867b'),
(44,1718627198,1,'BE',1,0,2,'sys_file_reference','{\"uid\":2,\"pid\":1,\"tstamp\":1718627198,\"crdate\":1718627198,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":2,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$470cfaf2f0def9c13c462dccab2c1467:814fc0f720dfab882655a795e23a5b66'),
(45,1718633706,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"title\":\"dengram\"},\"newRecord\":{\"title\":\"Dengram\"}}',0,'0400$9211f82440f5c91a6c117bf02fe85ec1:e175f7045d7ccbfb26ffcf279422c2e5'),
(46,1718633913,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"subtitle\":\"\"},\"newRecord\":{\"subtitle\":\"About us\"}}',0,'0400$f2334a6d2e9f49c4eed1e5ba9f440ac2:e175f7045d7ccbfb26ffcf279422c2e5'),
(47,1718634031,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"subtitle\":\"About us\"},\"newRecord\":{\"subtitle\":\"About Us\"}}',0,'0400$3de83d8d1d5adb4ec4bc07acee608f03:e175f7045d7ccbfb26ffcf279422c2e5'),
(48,1718634241,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Since we  started work in 1890\",\"bodytext\":\"<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n<p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n\\r\\n\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"Since we started work in 1890\",\"bodytext\":\"<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.<\\/p>\\r\\n<p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,<\\/p>\\r\\n<p><a class=\\\"site-button m-t15 m-b15\\\" href=\\\"project-detail.html\\\">Read More<\\/a><\\/p>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$f0a11fd28a15604d1ee380af8fff01bf:b92300cfb5d1d3645c9cb212a7f56c1f'),
(49,1718634397,1,'BE',1,0,7,'tt_content','{\"uid\":7,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718634397,\"crdate\":1718634397,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":16,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"html\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"<div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to intoriza<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":2,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$aea91d4623333182dcbb7473337dcff9:ea41b626baac59a1fe0716bc344af5d9'),
(50,1718634623,2,'BE',1,0,3,'tt_content','{\"oldRecord\":{\"header\":\"Since we started work in 1890\"},\"newRecord\":{\"header\":\"\"}}',0,'0400$3b5254aa199511361759ab6d0c477fac:b92300cfb5d1d3645c9cb212a7f56c1f'),
(51,1718639515,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"hidden\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"1\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$283be09652fd29ce8ba7ec5286dcf283:c0db6803ab1ec5f70c36e2a72187867b'),
(52,1718639553,2,'BE',1,0,5,'tt_content','{\"oldRecord\":{\"hidden\":0,\"l18n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"1\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$0992b53235cf3ad0fb081299e45c6e32:c7626fc9bcba6f70beb6ebc085a400db'),
(53,1718639760,2,'BE',1,0,7,'tt_content','{\"oldRecord\":{\"bodytext\":\"<div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to intoriza<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"bodytext\":\"<div class=\\\"section-head\\\">\\r\\n                                \\t<div class=\\\"wt-separator-outer separator-left\\\">\\r\\n                                \\t\\t<div class=\\\"wt-separator\\\">\\r\\n                                            <span class=\\\"site-text-primary text-uppercase sep-line-one \\\">Welcome to Dengram Alumni<\\/span>\\r\\n                                        <\\/div>\\r\\n                                    <\\/div>\\r\\n                                    <h2>Since we <br> started work in 1890<\\/h2>\\r\\n                                <\\/div>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$67594b5494680963673fbfdff831a706:ea41b626baac59a1fe0716bc344af5d9'),
(54,1718701259,1,'BE',1,0,8,'tt_content','{\"uid\":8,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718701259,\"crdate\":1718701259,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":8,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"The Executives\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"Our Old Boys\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$0ce5ef848cd2fe34e4578eafe1d99d49:2097d84972a039cb6bfe093b17089287'),
(55,1718701431,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_position\":\"\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header_position\":\"center\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$fe8616d5ddc86dca714f3bb826cfbf05:2097d84972a039cb6bfe093b17089287'),
(56,1718712072,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_layout\":\"0\",\"header_position\":\"center\"},\"newRecord\":{\"header_layout\":\"2\",\"header_position\":\"right\"}}',0,'0400$97cc1adc393c12be67620dc7d9535501:2097d84972a039cb6bfe093b17089287'),
(57,1718712223,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_layout\":\"2\"},\"newRecord\":{\"header_layout\":\"1\"}}',0,'0400$799762f6ce7cd69ec1a0b14d14f52d73:2097d84972a039cb6bfe093b17089287'),
(58,1718712379,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_layout\":\"1\"},\"newRecord\":{\"header_layout\":\"2\"}}',0,'0400$1659814612b5ab53e70e498bab887ee1:2097d84972a039cb6bfe093b17089287'),
(59,1718712430,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_position\":\"right\"},\"newRecord\":{\"header_position\":\"center\"}}',0,'0400$751440a8cd1d443a36d6427dba172c71:2097d84972a039cb6bfe093b17089287'),
(60,1718715683,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_layout\":\"2\"},\"newRecord\":{\"header_layout\":\"3\"}}',0,'0400$6e4b6432c943a9c318556fe56a7fad31:2097d84972a039cb6bfe093b17089287'),
(61,1718715874,2,'BE',1,0,8,'tt_content','{\"oldRecord\":{\"header_layout\":\"3\"},\"newRecord\":{\"header_layout\":\"2\"}}',0,'0400$195bd5d40e725c28fe42678c29c6d8da:2097d84972a039cb6bfe093b17089287'),
(62,1718716056,1,'BE',1,0,9,'tt_content','{\"uid\":9,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718716056,\"crdate\":1718716056,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":4,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"Since we started work in 1890\",\"header_position\":\"center\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":2,\"subheader\":\"Welcome to Dengram Alumni\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"2\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0}',0,'0400$4ce2c2cca3520e5f5ee4fa4bed362000:367f4f227870d8e2a11496a182574aa3'),
(63,1718716078,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"header_position\":\"center\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header_position\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$ec494c5f4f0b648d6efb3a05c78393aa:367f4f227870d8e2a11496a182574aa3'),
(64,1718716094,4,'BE',1,0,7,'tt_content',NULL,0,'0400$aa35ee228b8a700d8bf6a0be3afa4d00:ea41b626baac59a1fe0716bc344af5d9'),
(65,1718716540,1,'BE',1,0,3,'sys_file_reference','{\"uid\":3,\"pid\":1,\"tstamp\":1718716540,\"crdate\":1718716540,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0}',0,'0400$a37f7607feb2533a7e1fb3e7d187a63d:d2c609347a4764200256b39b9425159a'),
(66,1718882412,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript\"}}',0,'0400$f792fa3c3426720ced94eb7c6766194b:35af6288617af54964e77af08c30949a'),
(67,1718882450,1,'BE',1,0,8,'pages','{\"uid\":8,\"pid\":1,\"tstamp\":1718882450,\"crdate\":1718882450,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":480,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Teams\",\"doktype\":254,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/teams\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$1b5c0238893ecd07c209083fff709360:595375f2fb9f014e091eb08fbc51ec88'),
(68,1718882455,2,'BE',1,0,8,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$8f2fd1a9af5961643e06402d57da01a4:595375f2fb9f014e091eb08fbc51ec88'),
(69,1718883088,1,'BE',1,0,9,'pages','{\"uid\":9,\"pid\":1,\"tstamp\":1718883088,\"crdate\":1718883088,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"0\",\"sorting\":160,\"rowDescription\":null,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Member\",\"doktype\":1,\"TSconfig\":null,\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":null,\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":null,\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":null,\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":null,\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/member\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":null,\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":null,\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$da9e52179946304356248829fba4866a:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(70,1718883092,2,'BE',1,0,9,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$3557fa23a77f113f77c4040fc820c24e:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(71,1718883101,2,'BE',1,0,9,'pages','{\"oldRecord\":{\"nav_hide\":0,\"fe_group\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"nav_hide\":\"1\",\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$eb95c9fced60fa170d52139e0cd6f702:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(72,1718883126,3,'BE',1,0,9,'pages','{\"oldPageId\":1,\"newPageId\":1,\"oldData\":{\"header\":\"Member\",\"pid\":1,\"event_pid\":9,\"t3ver_state\":0},\"newData\":{\"tstamp\":1718883126,\"pid\":1,\"sorting\":144}}',0,'0400$73ed35792c6e9896cd6450818f285a8d:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(73,1718883142,4,'BE',1,0,9,'pages',NULL,0,'0400$5f311649acc6503e2aa1257cfa1554db:c5e7fa6b7b8146bdcdc78407b052e1d7'),
(74,1718883266,1,'BE',1,0,10,'pages','{\"uid\":10,\"pid\":4,\"tstamp\":1718883266,\"crdate\":1718883266,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"Set\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":1,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/membership\\/set\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$5ab354b19d0365dd63f095b041496ead:e904af5a60392ab3165f5849f5877e45'),
(75,1718884662,1,'BE',1,0,1,'tx_news_domain_model_news','{\"uid\":1,\"pid\":8,\"tstamp\":1718884662,\"crdate\":1718884662,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"l10n_source\":0,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"l10n_state\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"cruser_id\":0,\"sorting\":0,\"title\":\"Anne Ezurike\",\"teaser\":\"My name is Anne Ezurike, a software developer\",\"bodytext\":\"\",\"datetime\":1718883299,\"archive\":0,\"author\":\"\",\"author_email\":\"\",\"categories\":0,\"related\":0,\"related_from\":0,\"related_files\":null,\"fal_related_files\":0,\"related_links\":0,\"type\":\"0\",\"keywords\":\"\",\"description\":\"\",\"tags\":0,\"media\":null,\"fal_media\":0,\"internalurl\":null,\"externalurl\":null,\"istopnews\":0,\"content_elements\":0,\"path_segment\":\"anne-ezurike\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"import_id\":\"\",\"import_source\":\"\"}',0,'0400$ed399b20adf0c462aaebf76387800501:fccd16ea3664ec003726b2a72ea38f4b'),
(76,1718884662,1,'BE',1,0,4,'sys_file_reference','{\"uid\":4,\"pid\":8,\"tstamp\":1718884662,\"crdate\":1718884662,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":8,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":1}',0,'0400$ed399b20adf0c462aaebf76387800501:cea5fcd7b97871880cfe3717d6b52ef4'),
(77,1718884991,1,'BE',1,0,1,'sys_category','{\"uid\":1,\"pid\":1,\"tstamp\":1718884991,\"crdate\":1718884991,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":256,\"description\":\"\",\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"members\",\"items\":0,\"parent\":0,\"fe_group\":\"0\",\"images\":0,\"single_pid\":0,\"shortcut\":0,\"import_id\":\"\",\"import_source\":\"\",\"seo_title\":\"\",\"seo_description\":\"\",\"seo_headline\":\"\",\"seo_text\":\"\",\"slug\":\"members\"}',0,'0400$88c61b18185faf68d2221794f480e8fe:c6c8e24453121a7d668fe4b1031ebf88'),
(78,1718885062,1,'BE',1,0,2,'sys_category','{\"uid\":2,\"pid\":1,\"tstamp\":1718885062,\"crdate\":1718885062,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"sorting\":128,\"description\":\"\",\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"title\":\"2015\",\"items\":0,\"parent\":1,\"fe_group\":\"0\",\"images\":0,\"single_pid\":0,\"shortcut\":0,\"import_id\":\"\",\"import_source\":\"\",\"seo_title\":\"\",\"seo_description\":\"\",\"seo_headline\":\"\",\"seo_text\":\"\",\"slug\":\"2015\"}',0,'0400$c4bef12538d0e0b3cfbe03955febe526:497028e4af2a2cda8419e90cde34f71b'),
(79,1718885091,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"categories\":\"\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"categories\":\"2\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$8ef28f5adc90c7a395ca27462c7e416f:fccd16ea3664ec003726b2a72ea38f4b'),
(80,1718885091,2,'BE',1,0,4,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$8ef28f5adc90c7a395ca27462c7e416f:cea5fcd7b97871880cfe3717d6b52ef4'),
(81,1718885507,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"istopnews\":0},\"newRecord\":{\"istopnews\":\"1\"}}',0,'0400$f12a267be84e324821ece076f35fc2bc:fccd16ea3664ec003726b2a72ea38f4b'),
(82,1718885671,1,'BE',1,0,10,'tt_content','{\"uid\":10,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718885671,\"crdate\":1718885671,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":20,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newsselectedlist\",\"header\":\"top members\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"100\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$c8a9657e049ef607a91a18955ca521b7:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(83,1718886143,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Partials\\/\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Layouts\\/\"}}',0,'0400$fea889a544ff81610890d065a0b5dc2a:35af6288617af54964e77af08c30949a'),
(84,1718887662,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Partials\\/\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Layouts\\/\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$af3fcc31f52539f470d807094c95d761:35af6288617af54964e77af08c30949a'),
(85,1718897264,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/\"}}',0,'0400$6e7610c5507b3ace335ced4defe3287b:35af6288617af54964e77af08c30949a'),
(86,1718897292,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$69bc00e0dac797874fb4c2b364fc2ac9:35af6288617af54964e77af08c30949a'),
(87,1718897342,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\"}}',0,'0400$a836165a33fd8933f7f6534a843542de:35af6288617af54964e77af08c30949a'),
(88,1718897405,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Partials\\/\"}}',0,'0400$4bb7158a229658087460126572574efa:35af6288617af54964e77af08c30949a'),
(89,1718897436,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Partials\\/\"},\"newRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Partials\\/\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Templates\\/\"}}',0,'0400$b7cf40e22c189eca6359746cdec675cd:35af6288617af54964e77af08c30949a'),
(90,1718905440,1,'BE',1,0,2,'tx_news_domain_model_news','{\"uid\":2,\"pid\":8,\"tstamp\":1718905440,\"crdate\":1718905440,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"l10n_source\":0,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"l10n_state\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"cruser_id\":0,\"sorting\":0,\"title\":\"Austine Iheanacho\",\"teaser\":\"Some writeup about Austin\",\"bodytext\":\"\",\"datetime\":1718905019,\"archive\":0,\"author\":\"\",\"author_email\":\"\",\"categories\":1,\"related\":0,\"related_from\":0,\"related_files\":null,\"fal_related_files\":0,\"related_links\":0,\"type\":\"0\",\"keywords\":\"\",\"description\":\"\",\"tags\":0,\"media\":null,\"fal_media\":0,\"internalurl\":null,\"externalurl\":null,\"istopnews\":0,\"content_elements\":0,\"path_segment\":\"austine-iheanacho\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"import_id\":\"\",\"import_source\":\"\"}',0,'0400$a1fe933af88072228f64fe895237f0ba:640f28e5c1a5ec2efb19c26699b464a5'),
(91,1718905440,1,'BE',1,0,5,'sys_file_reference','{\"uid\":5,\"pid\":8,\"tstamp\":1718905440,\"crdate\":1718905440,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":9,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$a1fe933af88072228f64fe895237f0ba:5f15a1453f67b933ed3314381f5d67e4'),
(92,1718905485,2,'BE',1,0,2,'tx_news_domain_model_news','{\"oldRecord\":{\"istopnews\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"istopnews\":\"1\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$00442f667d713eb18125d65f76da0f9a:640f28e5c1a5ec2efb19c26699b464a5'),
(93,1718905485,2,'BE',1,0,5,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$00442f667d713eb18125d65f76da0f9a:5f15a1453f67b933ed3314381f5d67e4'),
(94,1718906593,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">1,2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$10b833494e8b5310284e8215009959be:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(95,1718907073,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">1,2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$7ce1185f438f75c73f7f818cbb7e3057:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(96,1718907092,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">2,1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$02a17b4b02c813f350dfaa5f1495c49f:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(97,1718908060,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$11ba6ced063c533c3c49b19779bd8922:fccd16ea3664ec003726b2a72ea38f4b'),
(98,1718908088,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$d6588ca48dde580d68b4c5c7a902fe26:fccd16ea3664ec003726b2a72ea38f4b'),
(99,1718908319,2,'BE',1,0,2,'tx_news_domain_model_news','{\"oldRecord\":{\"hidden\":0,\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$daa8410f2aea90056043828f96ace8fe:640f28e5c1a5ec2efb19c26699b464a5'),
(100,1718908331,2,'BE',1,0,2,'tx_news_domain_model_news','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$71307e2865dfda4101a9c68d6b494f94:640f28e5c1a5ec2efb19c26699b464a5'),
(101,1718908377,2,'BE',1,0,2,'tx_news_domain_model_news','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$ccff0f5af03a42cf2fd6d21196f2fdf3:640f28e5c1a5ec2efb19c26699b464a5'),
(102,1718908377,1,'BE',1,0,6,'sys_file_reference','{\"uid\":6,\"pid\":8,\"tstamp\":1718908377,\"crdate\":1718908377,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":9,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$ccff0f5af03a42cf2fd6d21196f2fdf3:768f9cd4e98812f969df7ebe17f11b50'),
(103,1718908377,2,'BE',1,0,2,'tx_news_domain_model_news','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$ccff0f5af03a42cf2fd6d21196f2fdf3:640f28e5c1a5ec2efb19c26699b464a5'),
(104,1718908377,4,'BE',1,0,5,'sys_file_reference',NULL,0,'0400$ccff0f5af03a42cf2fd6d21196f2fdf3:5f15a1453f67b933ed3314381f5d67e4'),
(105,1718908395,2,'BE',1,0,6,'sys_file_reference','{\"oldRecord\":{\"showinpreview\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"showinpreview\":\"1\",\"l10n_diffsource\":\"{\\\"showinpreview\\\":\\\"\\\",\\\"alternative\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$dd131979a44f91b048778c8f6ddd3acd:768f9cd4e98812f969df7ebe17f11b50'),
(106,1718908821,1,'BE',1,0,11,'tt_content','{\"uid\":11,\"rowDescription\":\"\",\"pid\":4,\"tstamp\":1718908821,\"crdate\":1718908821,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newssearchform\",\"header\":\"Search box\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":1,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$cbc76eb2e3b1fb8e730262d2e76a7074:7a14c618500ae24604910dfdd2f8ff12'),
(107,1718909582,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$deaa4054af31b0d07392fb7407ced4f1:412add0b3eb6ec8f1cb6710aea92e21e'),
(108,1718909582,1,'BE',1,0,7,'sys_file_reference','{\"uid\":7,\"pid\":4,\"tstamp\":1718909582,\"crdate\":1718909582,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$deaa4054af31b0d07392fb7407ced4f1:117c97010b9af15cb554d115dba4e316'),
(109,1718909582,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"fe_group\":\"0\",\"l10n_diffsource\":\"\"},\"newRecord\":{\"fe_group\":\"\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$deaa4054af31b0d07392fb7407ced4f1:412add0b3eb6ec8f1cb6710aea92e21e'),
(110,1718909836,2,'BE',1,0,4,'pages','{\"oldRecord\":{\"subtitle\":\"\"},\"newRecord\":{\"subtitle\":\"Members\"}}',0,'0400$b67da368418ce5dfe318bb2746e29c5a:412add0b3eb6ec8f1cb6710aea92e21e'),
(111,1718909836,2,'BE',1,0,7,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$b67da368418ce5dfe318bb2746e29c5a:117c97010b9af15cb554d115dba4e316'),
(112,1718910110,1,'BE',1,0,12,'tt_content','{\"uid\":12,\"rowDescription\":\"\",\"pid\":4,\"tstamp\":1718910110,\"crdate\":1718910110,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":128,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"\",\"header_position\":\"center\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"Members Search form\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"2\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$dbf4541cfc9b72fd3cb4d64d73b2e77a:b13bbccfb8e2fc277be02db62485ced6'),
(113,1718910579,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"header\":\"Search box\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"header\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$24d3905e8638748976fe11f9251b5ccf:7a14c618500ae24604910dfdd2f8ff12'),
(114,1718954076,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.tx_news.view.layoutRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Layouts\\/\\nplugin.tx_news.view.partialRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Partials\\/\\nplugin.tx_news.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Extensions\\/News\\/Templates\\/\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$1f0ea757785d41abe21b4ff0a3d68c06:35af6288617af54964e77af08c30949a'),
(115,1718956379,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"hidden\":0,\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"1\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$4432b9c28ef1354190b8abd781100bbf:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(116,1718956390,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$0a591c39bc5206761f0aa0098313b33e:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(117,1718958187,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"hidden\":1},\"newRecord\":{\"hidden\":\"0\"}}',0,'0400$40647613e6922395970960e08cf8245a:c0db6803ab1ec5f70c36e2a72187867b'),
(118,1718958189,2,'BE',1,0,6,'tt_content','{\"oldRecord\":{\"hidden\":0},\"newRecord\":{\"hidden\":\"1\"}}',0,'0400$c3988c2c115e0e39c12ddf47e6f185d0:c0db6803ab1ec5f70c36e2a72187867b'),
(119,1718958234,1,'BE',1,0,13,'tt_content','{\"uid\":13,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1718958234,\"crdate\":1718958234,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":2,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"html\",\"header\":\"welcome bg\",\"header_position\":\"\",\"bodytext\":\"<div class=\\\"welcome-carousel-outer m-b60\\\">\\r\\n                      <div class=\\\"welcome-bg-block clearfix\\\">\\r\\n                           <div class=\\\"welcome-carousel-1 \\\">\\r\\n                               <div class=\\\"owl-carousel home-carousel-1 owl-btn-bottom-left\\\">\\r\\n                                   <!-- COLUMNS 1 -->\\r\\n                                   <div class=\\\"item\\\">\\r\\n                                       <div class=\\\"ow-img\\\">\\r\\n                                           <a href=\\\"#\\\"><img src=\\\"\\/fileadmin\\/dengram\\/welcome-slider\\/1.jpg\\\" alt=\\\"\\\"><\\/a>\\r\\n                                       <\\/div>\\r\\n                                   <\\/div>\\r\\n                                   \\r\\n                              <\\/div>\\r\\n                           <\\/div>                                 \\r\\n                      <\\/div>\\r\\n                  <\\/div>\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":1,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$d3922b9f0516fde58bcf0b6b6569f4eb:aa58d78b4f5fe95c0d2d1cb36d041737'),
(120,1718958920,4,'BE',1,0,13,'tt_content',NULL,0,'0400$375dd9888afd4e1262b627e8c7a864a9:aa58d78b4f5fe95c0d2d1cb36d041737'),
(121,1718958957,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"subtitle\":\"About Us\"},\"newRecord\":{\"subtitle\":\"Dengram Alumni 1997 Set\"}}',0,'0400$64969c8a0c552e920eef30c54c29c585:e175f7045d7ccbfb26ffcf279422c2e5'),
(122,1718958957,2,'BE',1,0,3,'sys_file_reference','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"alternative\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"link\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"crop\\\":\\\"\\\",\\\"uid_local\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\"}\"}}',0,'0400$64969c8a0c552e920eef30c54c29c585:d2c609347a4764200256b39b9425159a'),
(123,1718959363,2,'BE',1,0,10,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">2,1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.selectedList\\\">\\n                    <value index=\\\"vDEF\\\">2,1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$4f31ab27501d9962f00874ec0dc5e67d:7ea9bfd0f5c1068d25caf6ccac9d6265'),
(124,1718959624,2,'BE',1,0,10,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$791d6281103492c350ba7b2829b98139:e904af5a60392ab3165f5849f5877e45'),
(125,1718959624,1,'BE',1,0,8,'sys_file_reference','{\"uid\":8,\"pid\":10,\"tstamp\":1718959624,\"crdate\":1718959624,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$791d6281103492c350ba7b2829b98139:5ff44a4f59fb3bfbe13a2c3ed1d0bd8b'),
(126,1718959624,2,'BE',1,0,10,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$791d6281103492c350ba7b2829b98139:e904af5a60392ab3165f5849f5877e45'),
(127,1718959935,1,'BE',1,0,14,'tt_content','{\"uid\":14,\"rowDescription\":\"\",\"pid\":10,\"tstamp\":1718959935,\"crdate\":1718959935,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"header\",\"header\":\"Member Detail\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$d83af7c2db6d42a5cbaf45950c5552ba:338e104baa774eacaec42da729015b5f'),
(128,1718960033,1,'BE',1,0,15,'tt_content','{\"uid\":15,\"rowDescription\":\"\",\"pid\":10,\"tstamp\":1718960033,\"crdate\":1718960033,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newsdetail\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.singleNews\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$933b50416d918d5213d8046861bbe2d0:cb118fde3da18e67b21a92b60bb8cbda'),
(129,1718960402,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"bodytext\":\"\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"bodytext\":\"<p>Some write up to see how it looks. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.<\\/p>\",\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$a563385c1aebc470066994eb8f0081bb:fccd16ea3664ec003726b2a72ea38f4b'),
(130,1718962666,4,'BE',1,0,14,'tt_content',NULL,0,'0400$b47cbb7f9d6c0c9d906cbe56b1ef46e2:338e104baa774eacaec42da729015b5f'),
(131,1718963138,2,'BE',1,0,1,'tx_news_domain_model_news','{\"oldRecord\":{\"teaser\":\"My name is Anne Ezurike, a software developer\"},\"newRecord\":{\"teaser\":\"Software Developer\"}}',0,'0400$9acf60977d6d70316dd1d87f9db34168:fccd16ea3664ec003726b2a72ea38f4b'),
(132,1718967106,1,'BE',1,0,11,'pages','{\"uid\":11,\"pid\":4,\"tstamp\":1718967106,\"crdate\":1718967106,\"deleted\":0,\"hidden\":1,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":128,\"rowDescription\":\"\",\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"List\",\"doktype\":1,\"TSconfig\":\"\",\"is_siteroot\":0,\"php_tree_stop\":0,\"url\":\"\",\"shortcut\":0,\"shortcut_mode\":0,\"subtitle\":\"\",\"layout\":0,\"target\":\"\",\"media\":0,\"keywords\":\"\",\"cache_timeout\":0,\"cache_tags\":\"\",\"description\":\"\",\"no_search\":0,\"SYS_LASTCHANGED\":0,\"abstract\":\"\",\"module\":\"\",\"extendToSubpages\":0,\"author\":\"\",\"author_email\":\"\",\"nav_title\":\"\",\"nav_hide\":0,\"content_from_pid\":0,\"mount_pid\":0,\"mount_pid_ol\":0,\"l18n_cfg\":0,\"backend_layout\":\"\",\"backend_layout_next_level\":\"\",\"tsconfig_includes\":\"\",\"categories\":0,\"lastUpdated\":0,\"newUntil\":0,\"slug\":\"\\/membership\\/list\",\"tx_impexp_origuid\":0,\"seo_title\":\"\",\"no_index\":0,\"no_follow\":0,\"og_title\":\"\",\"og_description\":\"\",\"og_image\":0,\"twitter_title\":\"\",\"twitter_description\":\"\",\"twitter_image\":0,\"twitter_card\":\"summary\",\"canonical_link\":\"\",\"sitemap_priority\":\"0.5\",\"sitemap_changefreq\":\"\"}',0,'0400$04934e985d91e567351ccaf0f2e70ae7:51bca2bcf14079cc366c99de31802400'),
(133,1718967150,2,'BE',1,0,11,'pages','{\"oldRecord\":{\"nav_hide\":0,\"l10n_diffsource\":\"\"},\"newRecord\":{\"nav_hide\":\"1\",\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$1b73cc1f62cccfc02226d324c3c1efab:51bca2bcf14079cc366c99de31802400'),
(134,1718967154,2,'BE',1,0,11,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$98062fc1cefcb2d241defc5efbbf90eb:51bca2bcf14079cc366c99de31802400'),
(135,1718967281,1,'BE',1,0,16,'tt_content','{\"uid\":16,\"rowDescription\":\"\",\"pid\":4,\"tstamp\":1718967281,\"crdate\":1718967281,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":512,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newssearchresult\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\">and<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$ca73f795d88bc618c13e28c63d0355bd:43f02d513e41a72738b96558f7ee9015'),
(136,1718967462,2,'BE',1,0,16,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\">and<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$33ee46adf754112afadbc5b157cb1b8d:43f02d513e41a72738b96558f7ee9015'),
(137,1718967479,2,'BE',1,0,16,'tt_content','{\"oldRecord\":{\"header\":\"\"},\"newRecord\":{\"header\":\"Search result\"}}',0,'0400$25ddacfded38ad7b0899143a88a123bc:43f02d513e41a72738b96558f7ee9015'),
(138,1718970612,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">4<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$ab5d55e3a3cea027461361742c98ec95:7a14c618500ae24604910dfdd2f8ff12'),
(139,1718970775,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">4<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">11<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$459fe975d4dd053407c3f9f9cfe0ed8a:7a14c618500ae24604910dfdd2f8ff12'),
(140,1718971089,1,'BE',1,0,17,'tt_content','{\"uid\":17,\"rowDescription\":\"\",\"pid\":11,\"tstamp\":1718971089,\"crdate\":1718971089,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":256,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newssearchresult\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$131aa88eefbe0358991aec6a16fd1988:017157395cc6da9e5d2911de6dfd4b9e'),
(141,1718972088,2,'BE',1,0,11,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$718deb520d2908c155bad263919172bd:51bca2bcf14079cc366c99de31802400'),
(142,1718972088,1,'BE',1,0,9,'sys_file_reference','{\"uid\":9,\"pid\":11,\"tstamp\":1718972088,\"crdate\":1718972088,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":7,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$718deb520d2908c155bad263919172bd:729356755eb8ee035abf6b9b02e20c8f'),
(143,1718972088,2,'BE',1,0,11,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"doktype\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"nav_title\\\":\\\"\\\",\\\"subtitle\\\":\\\"\\\",\\\"seo_title\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"no_index\\\":\\\"\\\",\\\"no_follow\\\":\\\"\\\",\\\"canonical_link\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"og_title\\\":\\\"\\\",\\\"og_description\\\":\\\"\\\",\\\"og_image\\\":\\\"\\\",\\\"twitter_title\\\":\\\"\\\",\\\"twitter_description\\\":\\\"\\\",\\\"twitter_image\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\",\\\"abstract\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"backend_layout\\\":\\\"\\\",\\\"backend_layout_next_level\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"target\\\":\\\"\\\",\\\"cache_timeout\\\":\\\"\\\",\\\"cache_tags\\\":\\\"\\\",\\\"is_siteroot\\\":\\\"\\\",\\\"no_search\\\":\\\"\\\",\\\"php_tree_stop\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"media\\\":\\\"\\\",\\\"tsconfig_includes\\\":\\\"\\\",\\\"TSconfig\\\":\\\"\\\",\\\"l18n_cfg\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"extendToSubpages\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\"}\"}}',0,'0400$718deb520d2908c155bad263919172bd:51bca2bcf14079cc366c99de31802400'),
(144,1718972155,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">11<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">4<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$a533d575409f5bec5b38b5887353e4ad:7a14c618500ae24604910dfdd2f8ff12'),
(145,1718974158,2,'BE',1,0,16,'tt_content','{\"oldRecord\":{\"header_layout\":\"0\"},\"newRecord\":{\"header_layout\":\"100\"}}',0,'0400$e1ff206f8eccf3900365e3386de68791:43f02d513e41a72738b96558f7ee9015'),
(146,1718980921,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">4<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">11<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$7cc0f68bbcadc27e4f9377e33e7cdb1a:7a14c618500ae24604910dfdd2f8ff12'),
(147,1718980979,2,'BE',1,0,11,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">11<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\">10<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$ff63f443f924649e27d50ad99de3062a:7a14c618500ae24604910dfdd2f8ff12'),
(148,1718981045,1,'BE',1,0,18,'tt_content','{\"uid\":18,\"rowDescription\":\"\",\"pid\":10,\"tstamp\":1718981045,\"crdate\":1718981045,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":768,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"news_newssearchresult\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":null,\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":2,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.orderBy\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.orderDirection\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.dateField\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categoryConjunction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.categories\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.includeSubCategories\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.archiveRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.timeRestrictionHigh\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsRestriction\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.previewHiddenRecords\\\">\\n                    <value index=\\\"vDEF\\\">2<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.startingpoint\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.recursive\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"additional\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.detailPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.listPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.backPid\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.limit\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.offset\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.tags\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.hidePagination\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.list.paginate.itemsPerPage\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.topNewsFirst\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.excludeAlreadyDisplayedNews\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.disableOverrideDemand\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n        <sheet index=\\\"template\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.media.maxWidth\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.media.maxHeight\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.cropMaxCharacters\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.templateLayout\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0}',0,'0400$fad10b5179e444317081694db012b81f:0a64be1ae1f9096cc345beb76e5e2095'),
(149,1718987021,1,'BE',1,0,3,'tx_news_domain_model_news','{\"uid\":3,\"pid\":8,\"tstamp\":1718987021,\"crdate\":1718987021,\"editlock\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_diffsource\":\"\",\"l10n_source\":0,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"notes\":\"\",\"l10n_state\":null,\"t3_origuid\":0,\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"cruser_id\":0,\"sorting\":0,\"title\":\"Derrick Chimdalu\",\"teaser\":\"Junge\",\"bodytext\":\"<p>Some small writeup about me<\\/p>\",\"datetime\":1718986730,\"archive\":0,\"author\":\"\",\"author_email\":\"\",\"categories\":0,\"related\":0,\"related_from\":0,\"related_files\":null,\"fal_related_files\":0,\"related_links\":0,\"type\":\"0\",\"keywords\":\"\",\"description\":\"\",\"tags\":0,\"media\":null,\"fal_media\":0,\"internalurl\":null,\"externalurl\":null,\"istopnews\":0,\"content_elements\":0,\"path_segment\":\"derrick-chimdalu\",\"alternative_title\":\"D-boy\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"0.5\",\"import_id\":\"\",\"import_source\":\"\"}',0,'0400$60bf3ba8ab213542cd869a592ab8cfa4:1152fda277b2623b0152b5765fcb6b28'),
(150,1718987021,1,'BE',1,0,10,'sys_file_reference','{\"uid\":10,\"pid\":8,\"tstamp\":1718987021,\"crdate\":1718987021,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":9,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":0}',0,'0400$60bf3ba8ab213542cd869a592ab8cfa4:b34a074e38840d41041eaee66c42bb0d'),
(151,1718987063,2,'BE',1,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$132f7841178c0dc5e8a2e80fb05f8b59:1152fda277b2623b0152b5765fcb6b28'),
(152,1718987063,1,'BE',1,0,11,'sys_file_reference','{\"uid\":11,\"pid\":8,\"tstamp\":1718987063,\"crdate\":1718987063,\"deleted\":0,\"hidden\":0,\"sys_language_uid\":0,\"l10n_parent\":0,\"l10n_state\":null,\"l10n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"uid_local\":9,\"uid_foreign\":0,\"tablenames\":\"\",\"fieldname\":\"\",\"sorting_foreign\":0,\"title\":null,\"description\":null,\"alternative\":null,\"link\":\"\",\"crop\":\"{\\\"default\\\":{\\\"cropArea\\\":{\\\"x\\\":0,\\\"y\\\":0,\\\"width\\\":1,\\\"height\\\":1},\\\"selectedRatio\\\":\\\"NaN\\\",\\\"focusArea\\\":null}}\",\"autoplay\":0,\"showinpreview\":1}',0,'0400$132f7841178c0dc5e8a2e80fb05f8b59:b70904b959c6d327947fc437df028f6f'),
(153,1718987063,2,'BE',1,0,3,'tx_news_domain_model_news','{\"oldRecord\":{\"l10n_diffsource\":\"\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"type\\\":\\\"\\\",\\\"istopnews\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"path_segment\\\":\\\"\\\",\\\"teaser\\\":\\\"\\\",\\\"datetime\\\":\\\"\\\",\\\"archive\\\":\\\"\\\",\\\"bodytext\\\":\\\"\\\",\\\"content_elements\\\":\\\"\\\",\\\"fal_media\\\":\\\"\\\",\\\"fal_related_files\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"related\\\":\\\"\\\",\\\"related_links\\\":\\\"\\\",\\\"tags\\\":\\\"\\\",\\\"author\\\":\\\"\\\",\\\"author_email\\\":\\\"\\\",\\\"keywords\\\":\\\"\\\",\\\"description\\\":\\\"\\\",\\\"alternative_title\\\":\\\"\\\",\\\"sitemap_changefreq\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"sys_language_uid\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"fe_group\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"notes\\\":\\\"\\\"}\"}}',0,'0400$132f7841178c0dc5e8a2e80fb05f8b59:1152fda277b2623b0152b5765fcb6b28'),
(154,1718987063,4,'BE',1,0,10,'sys_file_reference',NULL,0,'0400$132f7841178c0dc5e8a2e80fb05f8b59:b34a074e38840d41041eaee66c42bb0d'),
(155,1718987124,2,'BE',1,0,1,'pages','{\"oldRecord\":{\"subtitle\":\"Dengram Alumni 1997 Set\"},\"newRecord\":{\"subtitle\":\"Dengram Alumni 2000 Set\"}}',0,'0400$5819a600a245a0b81625058360a4add3:e175f7045d7ccbfb26ffcf279422c2e5'),
(156,1718987204,2,'BE',1,0,9,'tt_content','{\"oldRecord\":{\"header\":\"Since we started work in 1890\"},\"newRecord\":{\"header\":\"Since we started work in 1925\"}}',0,'0400$d22e9cbdd18ff0208eab2cea88657a83:367f4f227870d8e2a11496a182574aa3'),
(157,1724684137,1,'BE',1,0,19,'tt_content','{\"uid\":19,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1724684137,\"crdate\":1724684137,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":96,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"textteaser\",\"header\":\"Some Text\",\"header_position\":\"\",\"bodytext\":\"\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":0,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0,\"header_class\":\"\",\"subheader_class\":\"\",\"teaser\":\"With teaser\",\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"\",\"icon_size\":\"default\",\"icon_type\":\"default\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_title\":\"\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"frame_options\":\"\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"behaviour\\\">\\n                    <value index=\\\"vDEF\\\">cover<\\/value>\\n                <\\/field>\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"subitems_header_layout\":2}',0,'0400$06f40b9bb6f45752d661e765276fbd2b:a3ad11e2f7df6d0ba2d2b3c8402ba49d'),
(158,1724685244,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement\"}}',0,'0400$ab49ab65e5d581ba5f4ea8937a66015f:35af6288617af54964e77af08c30949a'),
(159,1724687021,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\"},\"newRecord\":{\"constants\":\"\\nplugin.bootstrap_package_contentelements.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/ContentElements\\/\"}}',0,'0400$6790c26fa1f879009f3c7d3d4532e46f:35af6288617af54964e77af08c30949a'),
(160,1724744941,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"constants\":\"\\nplugin.bootstrap_package_contentelements.view.templateRootPath = EXT:dengram_package\\/Resources\\/Private\\/Templates\\/ContentElements\\/\"},\"newRecord\":{\"constants\":\"\"}}',0,'0400$1e49e3b4698ee251dc7cbd0328bcda47:35af6288617af54964e77af08c30949a'),
(161,1724745403,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement\"},\"newRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\"}}',0,'0400$74c15c920bf42902341cc7fc579f250f:35af6288617af54964e77af08c30949a'),
(162,1724745463,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\"},\"newRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement\"}}',0,'0400$83cb5849a1f8b59016d78e823172e73b:35af6288617af54964e77af08c30949a'),
(163,1724745800,2,'BE',1,0,1,'sys_template','{\"oldRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement\"},\"newRecord\":{\"include_static_file\":\"EXT:dengram_package\\/Configuration\\/TypoScript,EXT:news\\/Configuration\\/TypoScript,EXT:bootstrap_package\\/Configuration\\/TypoScript\\/ContentElement\"}}',0,'0400$499e73f0016437e128549374fadbac6d:35af6288617af54964e77af08c30949a'),
(164,1724859121,1,'BE',1,0,20,'tt_content','{\"uid\":20,\"rowDescription\":\"\",\"pid\":1,\"tstamp\":1724859121,\"crdate\":1724859121,\"deleted\":0,\"hidden\":0,\"starttime\":0,\"endtime\":0,\"fe_group\":\"\",\"sorting\":2,\"editlock\":0,\"sys_language_uid\":0,\"l18n_parent\":0,\"l10n_source\":0,\"l10n_state\":null,\"t3_origuid\":0,\"l18n_diffsource\":\"\",\"t3ver_oid\":0,\"t3ver_wsid\":0,\"t3ver_state\":0,\"t3ver_stage\":0,\"CType\":\"texticon\",\"header\":\"\",\"header_position\":\"\",\"bodytext\":\"\",\"bullets_type\":0,\"uploads_description\":0,\"uploads_type\":0,\"assets\":0,\"image\":0,\"imagewidth\":0,\"imageorient\":0,\"imagecols\":1,\"imageborder\":0,\"media\":0,\"layout\":0,\"frame_class\":\"default\",\"cols\":0,\"space_before_class\":\"\",\"space_after_class\":\"\",\"records\":null,\"pages\":null,\"colPos\":8,\"subheader\":\"\",\"header_link\":\"\",\"image_zoom\":0,\"header_layout\":\"0\",\"list_type\":\"\",\"sectionIndex\":1,\"linkToTop\":0,\"file_collections\":null,\"filelink_size\":0,\"filelink_sorting\":\"\",\"filelink_sorting_direction\":\"\",\"target\":\"\",\"recursive\":0,\"imageheight\":0,\"pi_flexform\":null,\"accessibility_title\":\"\",\"accessibility_bypass\":0,\"accessibility_bypass_text\":\"\",\"category_field\":\"\",\"table_class\":\"\",\"table_caption\":null,\"table_delimiter\":124,\"table_enclosure\":0,\"table_header_position\":0,\"table_tfoot\":0,\"categories\":0,\"selected_categories\":null,\"date\":0,\"tx_impexp_origuid\":0,\"tx_news_related_news\":0,\"header_class\":\"\",\"subheader_class\":\"\",\"teaser\":null,\"aspect_ratio\":\"1.3333333333333\",\"items_per_page\":10,\"readmore_label\":\"\",\"quote_source\":\"\",\"quote_link\":\"\",\"panel_class\":\"default\",\"file_folder\":null,\"icon\":\"\",\"icon_set\":\"\",\"icon_file\":0,\"icon_position\":\"left\",\"icon_size\":\"default\",\"icon_type\":\"square\",\"icon_color\":\"#FFFFFF\",\"icon_background\":\"#333333\",\"external_media_title\":\"\",\"external_media_source\":\"\",\"external_media_ratio\":\"\",\"tx_bootstrappackage_card_group_item\":0,\"tx_bootstrappackage_carousel_item\":0,\"tx_bootstrappackage_accordion_item\":0,\"tx_bootstrappackage_icon_group_item\":0,\"tx_bootstrappackage_tab_item\":0,\"tx_bootstrappackage_timeline_item\":0,\"frame_layout\":\"default\",\"frame_options\":\"\",\"background_color_class\":\"none\",\"background_image\":0,\"background_image_options\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"behaviour\\\">\\n                    <value index=\\\"vDEF\\\">cover<\\/value>\\n                <\\/field>\\n                <field index=\\\"parallax\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"fade\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"filter\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"subitems_header_layout\":2}',0,'0400$f0a3ebcc1a10efe2c12db983dd88ecc2:e4fcdfe5be41a63ffdd7ab7b888d9459');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(32) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
INSERT INTO `sys_http_report` VALUES
('40d9b990-ccd7-413e-b984-477f68165b64',0,1722844260,1722844260,'csp-report','backend',1722844260351994,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-zNhUu6iHbB8jKUmeH223bsVdD63HTI3_dIfkW72MNhDGEsQk9UkiUw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844260351994\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('8023aece-b132-4815-bf57-83bc7078cbae',0,1722844298,1722844298,'csp-report','backend',1722844298120094,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-vzlDeqDo5edF1O4XrQgj3_fojOcNh-OP5CaFn-OYKIAeSDU-UeUseg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844298120094\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('86efaa3e-1148-41ca-9053-7f5c673fea1d',0,1722844265,1722844265,'csp-report','backend',1722844260351994,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-zNhUu6iHbB8jKUmeH223bsVdD63HTI3_dIfkW72MNhDGEsQk9UkiUw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844260351994\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('8d5adf20-8698-47c0-a435-efb7c28d1378',0,1722844311,1722844311,'csp-report','backend',1722844298120094,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-vzlDeqDo5edF1O4XrQgj3_fojOcNh-OP5CaFn-OYKIAeSDU-UeUseg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844298120094\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('9831da29-1114-4e3e-b58b-2f414a57c109',0,1722844489,1722844489,'csp-report','backend',1722844489551450,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/sudo-mode\\/module?claim=c1ae5b3f700424d7e9fe18c407a694e4068456fc&hash=60c268c0e6ce573bbeb23b53c3d8652f266e872d\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-22xYszTcs8ODb-QeRakoD0OqCBGTcmfkXvuqNr1BdIcZRgE7ArVoIw\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844489551450\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":557,\"column-number\":1,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js\",\"status-code\":200,\"script-sample\":\"__webpack_require__.r(__webpack_exports_\"}','03a216eeb315746398c67681ec9219b6299fae4f'),
('ae6b67f9-c1dd-45eb-bda3-9dd2fab69c0c',0,1722844450,1722844450,'csp-report','backend',1722844298120094,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-vzlDeqDo5edF1O4XrQgj3_fojOcNh-OP5CaFn-OYKIAeSDU-UeUseg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844298120094\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('c7ed1e2b-ac93-482f-8e50-4a38c44b3f5c',0,1722844254,1722844254,'csp-report','backend',1722844222866256,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/605.1.15 (KHTML, like Gecko) Version\\/17.6 Safari\\/605.1.15\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/login?loginProvider=1433416747\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-6nXRH8agAj0M4_80DSg-jReROJBAdIvXB1ehUYnqfqkIl0MTFmWEWg\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844222866256\",\"blocked-uri\":\"eval\",\"status-code\":0,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js?bust=76085cecbec535dd5a3c94aaf9f60e2acc817ead\",\"line-number\":557,\"column-number\":5}','42043a542eb95639ee9db992ca91c36721bded13'),
('d991e68d-e955-41a2-b4b7-2fddb5596e5b',0,1722844575,1722844575,'csp-report','backend',1722844575242519,'{\"addr\":\"172.18.0.0\",\"agent\":\"Mozilla\\/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit\\/537.36 (KHTML, like Gecko) Chrome\\/127.0.0.0 Safari\\/537.36\"}','{\"document-uri\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/extensionBuilder\",\"referrer\":\"https:\\/\\/dengram.ddev.site\\/typo3\\/module\\/tools\\/ExtensionmanagerExtensionmanager\",\"violated-directive\":\"script-src\",\"effective-directive\":\"script-src\",\"original-policy\":\"default-src \'self\'; script-src \'self\' \'nonce-eOi0lc8Svkrxcb1Z7cHBesDdIkSQqK6SohccvOjv7RupiUZc5Ww4XA\' \'report-sample\'; style-src \'self\' \'unsafe-inline\' \'report-sample\'; style-src-attr \'unsafe-inline\' \'report-sample\'; img-src \'self\' data: *.ytimg.com *.vimeocdn.com https:\\/\\/extensions.typo3.org; worker-src \'self\' blob:; frame-src \'self\' blob: *.youtube-nocookie.com *.youtube.com *.vimeo.com; base-uri \'none\'; object-src \'none\'; report-uri https:\\/\\/dengram.ddev.site\\/typo3\\/@http-reporting?csp=report&requestTime=1722844575242519\",\"disposition\":\"enforce\",\"blocked-uri\":\"eval\",\"line-number\":557,\"column-number\":1,\"source-file\":\"https:\\/\\/dengram.ddev.site\\/_assets\\/705f31da96f0870eac9db412ee92df1f\\/JavaScript\\/main.js\",\"status-code\":200,\"script-sample\":\"__webpack_require__.r(__webpack_exports_\"}','03a216eeb315746398c67681ec9219b6299fae4f');
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=265 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `details_nr` smallint(6) NOT NULL DEFAULT 0,
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `NEWid` varchar(30) NOT NULL DEFAULT '',
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `channel` (`channel`),
  KEY `level` (`level`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=654 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,0,1718360188,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(2,0,1718360202,1,1,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"pageTitle\":\"[root-level]\",\"pid\":0}',0,0,'NEW_1','',0,'','info',NULL,NULL),
(3,0,1718360202,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",1]',-1,0,'','',0,'','info',NULL,NULL),
(4,0,1718360202,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"2\"}',1,0,'','',0,'','info',NULL,NULL),
(5,0,1718360205,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"3\"}',1,0,'','',0,'','info',NULL,NULL),
(6,0,1718360224,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"4\"}',1,0,'','',0,'','info',NULL,NULL),
(7,0,1718360278,1,3,0,'site',0,0,'Site configuration \'%s\' was renamed to \'%s\'.',6,'site',0,'172.18.0.5','[\"autogenerated-1-c4ca4238a0b923820dcc509a6f75849b\",\"dengram-package\"]',-1,0,'','',0,'','info',NULL,NULL),
(8,0,1718360278,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site',0,'172.18.0.5','[\"dengram-package\"]',-1,0,'','',0,'','info',NULL,NULL),
(9,0,1718360361,1,1,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":2,\"pageTitle\":\"[root-level]\",\"pid\":0}',0,0,'NEW_1','',0,'','info',NULL,NULL),
(10,0,1718360361,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\",2]',-1,0,'','',0,'','info',NULL,NULL),
(11,0,1718360361,1,2,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":2,\"history\":\"6\"}',2,0,'','',0,'','info',NULL,NULL),
(12,0,1718360364,1,2,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":2,\"history\":\"7\"}',2,0,'','',0,'','info',NULL,NULL),
(13,0,1718360398,1,3,2,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":2,\"pageTitle\":\"[root-level]\",\"pid\":0}',2,0,'','',0,'','info',NULL,NULL),
(14,0,1718360530,1,1,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":3,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(15,0,1718360535,1,2,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":3,\"history\":\"10\"}',3,0,'','',0,'','info',NULL,NULL),
(16,0,1718360559,1,2,3,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":3,\"history\":\"11\"}',3,0,'','',0,'','info',NULL,NULL),
(17,0,1718360564,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1294587218: No TypoScript record found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/TypoScriptFrontendController.php in line 1195. Requested URL: https://dengram.ddev.site/home',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(18,0,1718362308,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(19,0,1718362315,1,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(20,0,1718362514,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(21,0,1718362673,1,1,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW666c21c87bd5b824182385','',0,'','info',NULL,NULL),
(22,0,1718362706,1,1,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Welcome\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW666c2244665cb314690888','',0,'','info',NULL,NULL),
(23,0,1718362744,1,3,1,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Welcome\",\"table\":\"tt_content\",\"uid\":1,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(24,0,1718369902,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(25,0,1718370047,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(26,0,1718370502,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(27,0,1718370759,1,1,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"About Us\\r\\n                            \\r\\n                        \\r\\n                                                    \\r\\n                        \\r\\n                            \\r\\n                        ...\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW666c41c136be5591692818','',0,'','info',NULL,NULL),
(28,0,1718370762,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(29,0,1718371038,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(30,0,1718371103,1,1,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Membership\",\"table\":\"pages\",\"uid\":4,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW0','',0,'','info',NULL,NULL),
(31,0,1718371103,1,1,5,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Projects\",\"table\":\"pages\",\"uid\":5,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW1','',0,'','info',NULL,NULL),
(32,0,1718371103,1,1,6,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Contact us\",\"table\":\"pages\",\"uid\":6,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW2','',0,'','info',NULL,NULL),
(33,0,1718371116,1,4,3,'pages',0,0,'Moved record \"{title}\" ({table}:{uid}) on page \"{pageTitle}\" ({pid})',1,'content',4,'172.18.0.5','{\"title\":\"Home\",\"table\":\"pages\",\"uid\":3,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(34,0,1718371119,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(35,0,1718375055,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(36,0,1718375335,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(37,0,1718375469,1,2,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Welcome\\r\\n                            \\r\\n                        \\r\\n                                                    \\r\\n                        \\r\\n                            \\r\\n                         ...\",\"table\":\"tt_content\",\"uid\":2,\"history\":\"20\"}',1,0,'','',0,'','info',NULL,NULL),
(38,0,1718375749,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(39,0,1718379665,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(40,0,1718379669,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(41,0,1718379679,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(42,0,1718379686,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(43,0,1718379798,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(44,0,1718379811,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(45,0,1718379813,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(46,0,1718379867,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(47,0,1718379870,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(48,0,1718379910,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"21\"}',1,0,'','',0,'','info',NULL,NULL),
(49,0,1718380011,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(50,0,1718380014,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(51,0,1718380017,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(52,0,1718380083,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(53,0,1718380114,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(54,0,1718380149,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"22\"}',1,0,'','',0,'','info',NULL,NULL),
(55,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(56,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(57,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(58,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(59,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(60,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(61,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(62,0,1718380176,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(63,0,1718380176,1,2,1,'pages',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',12,'172.18.0.5','{\"reason\":\"Unknown column \'nav_icon\' in \'field list\'\",\"table\":\"pages\",\"uid\":1}',-1,0,'','',0,'','info',NULL,NULL),
(64,0,1718380176,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Bpages%%5D%%5B1%%5D=edit&overrideVals%%5Bpages%%5D%%5Bsys_language_uid%%5D=0&returnUrl=%%2Ftypo3%%2Frecord%%2Fedit%%3Ftoken%%3D--AnonymizedToken--%%26edit%%255Bsys_template%%255D%%255B1%%255D%%3Dedit%%26returnUrl%%3D%%252Ftypo3%%252Fmodule%%252Fweb%%252Fts%%253Ftoken%%253Dcdcaa757a1db8ca3747a5faff26127aa08e6b3b7%%2526id%%253D1%%2526',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(65,0,1718380291,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(66,0,1718380318,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(67,0,1718380324,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(68,0,1718380357,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(69,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(70,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(71,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(72,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(73,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(74,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(75,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(76,0,1718380396,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(77,0,1718380396,1,2,1,'pages',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',12,'172.18.0.5','{\"reason\":\"Unknown column \'nav_icon\' in \'field list\'\",\"table\":\"pages\",\"uid\":1}',-1,0,'','',0,'','info',NULL,NULL),
(78,0,1718380396,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Bpages%%5D%%5B1%%5D=edit&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Finfo%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D1%%26',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(79,0,1718380461,1,1,7,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"engram_alumni\",\"table\":\"pages\",\"uid\":7,\"pageTitle\":\"[root-level]\",\"pid\":0}',0,0,'NEW_1','',0,'','info',NULL,NULL),
(80,0,1718380461,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site',0,'172.18.0.5','[\"autogenerated-7-8f14e45fceea167a5a36dedd4bea2543\",7]',-1,0,'','',0,'','info',NULL,NULL),
(81,0,1718380461,1,2,7,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"engram_alumni\",\"table\":\"pages\",\"uid\":7,\"history\":\"24\"}',7,0,'','',0,'','info',NULL,NULL),
(82,0,1718380461,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(83,0,1718380464,1,2,7,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"engram_alumni\",\"table\":\"pages\",\"uid\":7,\"history\":\"25\"}',7,0,'','',0,'','info',NULL,NULL),
(84,0,1718380464,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/record/commit?token=--AnonymizedToken--&data[pages][7][hidden]=0&redirect=%%2Ftypo3%%2Frecord%%2Fedit%%3Ftoken%%3D--AnonymizedToken--%%26edit%%255Bpages%%255D%%255B1%%255D%%3Dedit%%26returnUrl%%3D%%252Ftypo3%%252Fmodule%%252Fweb%%252Finfo%%253Ftoken%%253D3804ce1cbfad6c94388e0c249de959f7d12f5420%%2526id%%253D1%%2526',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(85,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(86,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(87,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(88,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(89,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(90,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(91,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(92,0,1718380484,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(93,0,1718380484,1,2,7,'pages',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',12,'172.18.0.5','{\"reason\":\"Unknown column \'nav_icon\' in \'field list\'\",\"table\":\"pages\",\"uid\":7}',-1,0,'','',0,'','info',NULL,NULL),
(94,0,1718380484,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Bpages%%5D%%5B7%%5D=edit&overrideVals%%5Bpages%%5D%%5Bsys_language_uid%%5D=0&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Finfo%%2Foverview%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D7',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(95,0,1718380491,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(96,0,1718380697,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(97,0,1718380768,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_bootstrappackage_accordion_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 49. Requested URL: http://dengram.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--&cmd[pages][7][delete]=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(98,0,1718380783,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_bootstrappackage_accordion_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 49. Requested URL: http://dengram.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--&cmd[pages][7][delete]=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(99,0,1718380795,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(100,0,1718380813,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":7}',-1,0,'','',0,'','info',NULL,NULL),
(101,0,1718380817,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(102,0,1718380827,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_bootstrappackage_accordion_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 49. Requested URL: http://dengram.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--&cmd[pages][7][delete]=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(103,0,1718380842,1,4,0,'site',0,0,'Site configuration \'%s\' was deleted.',6,'site',0,'172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\"]',-1,0,'','',0,'','info',NULL,NULL),
(104,0,1718380845,1,4,0,'site',0,0,'Site configuration \'%s\' was deleted.',6,'site',0,'172.18.0.5','[\"autogenerated-7-8f14e45fceea167a5a36dedd4bea2543\"]',-1,0,'','',0,'','info',NULL,NULL),
(105,0,1718380851,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_bootstrappackage_accordion_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 49. Requested URL: http://dengram.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--&cmd[pages][7][delete]=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(106,0,1718380857,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(107,0,1718381408,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(108,0,1718381787,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(109,0,1718381789,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(110,0,1718381790,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(111,0,1718381793,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(112,0,1718381795,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(113,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(114,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon_set\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(115,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(116,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(117,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"nav_icon\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(118,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(119,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8484',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(120,0,1718381832,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: Undefined array key \"thumbnail\" in /var/www/html/vendor/typo3/cms-core/Classes/DataHandling/DataHandler.php line 8488',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(121,0,1718381832,1,2,1,'pages',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',12,'172.18.0.5','{\"reason\":\"Unknown column \'nav_icon\' in \'field list\'\",\"table\":\"pages\",\"uid\":1}',-1,0,'','',0,'','info',NULL,NULL),
(122,0,1718381832,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1054: An exception occurred while executing a query: Unknown column \'nav_icon\' in \'field list\' | Doctrine\\DBAL\\Exception\\InvalidFieldNameException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 67. Requested URL: http://dengram.ddev.site/typo3/record/edit?token=--AnonymizedToken--&edit%%5Bpages%%5D%%5B1%%5D=edit&overrideVals%%5Bpages%%5D%%5Bsys_language_uid%%5D=0&returnUrl=%%2Ftypo3%%2Fmodule%%2Fweb%%2Fts%%3Ftoken%%3D--AnonymizedToken--%%26id%%3D1%%26',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(123,0,1718381990,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(124,0,1718382332,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"26\"}',1,0,'','',0,'','info',NULL,NULL),
(125,0,1718382343,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(126,0,1718382364,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"27\"}',1,0,'','',0,'','info',NULL,NULL),
(127,0,1718382367,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(128,0,1718382524,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(129,0,1718382642,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(130,0,1718383414,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(131,0,1718383983,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(132,0,1718384135,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(133,0,1718384205,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(134,0,1718384671,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"28\"}',1,0,'','',0,'','info',NULL,NULL),
(135,0,1718384674,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(136,0,1718384892,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(137,0,1718385874,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(138,0,1718387964,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(139,0,1718388959,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"29\"}',1,0,'','',0,'','info',NULL,NULL),
(140,0,1718388965,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(141,0,1718389064,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(142,0,1718389133,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(143,0,1718389182,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(144,0,1718389212,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"30\"}',1,0,'','',0,'','info',NULL,NULL),
(145,0,1718389224,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(146,0,1718389580,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(147,0,1718389587,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(148,0,1718615659,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(149,0,1718615663,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(150,0,1718616086,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"31\"}',1,0,'','',0,'','info',NULL,NULL),
(151,0,1718616094,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(152,0,1718617918,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(153,0,1718618632,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(154,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 91: parser error : Opening and ending tag mismatch: trans-unit line 90 and body in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(155,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():         &lt;/body&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(156,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():                ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(157,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 92: parser error : Opening and ending tag mismatch: body line 9 and file in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(158,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():     &lt;/file&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(159,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():            ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(160,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 93: parser error : Opening and ending tag mismatch: file line 3 and xliff in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(161,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): &lt;/xliff&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(162,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():         ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(163,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 94: parser error : Premature end of data in tag xliff line 2 in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(164,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():  in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(165,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(166,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 91: parser error : Opening and ending tag mismatch: trans-unit line 90 and body in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(167,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():         &lt;/body&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(168,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():                ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(169,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 92: parser error : Opening and ending tag mismatch: body line 9 and file in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(170,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():     &lt;/file&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(171,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():            ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(172,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 93: parser error : Opening and ending tag mismatch: file line 3 and xliff in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(173,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): &lt;/xliff&gt; in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(174,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():         ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(175,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): Entity: line 94: parser error : Premature end of data in tag xliff line 2 in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(176,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string():  in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(177,0,1718618635,1,0,0,'',0,2,'Core: Error handler (BE): PHP Warning: simplexml_load_string(): ^ in /var/www/html/vendor/typo3/cms-core/Classes/Localization/Parser/AbstractXmlParser.php line 106',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','warning',NULL,NULL),
(178,0,1718618807,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(179,0,1718618847,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(180,0,1718619645,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"32\"}',1,0,'','',0,'','info',NULL,NULL),
(181,0,1718619648,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(182,0,1718619681,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"33\"}',1,0,'','',0,'','info',NULL,NULL),
(183,0,1718619684,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(184,0,1718626023,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"34\"}',1,0,'','',0,'','info',NULL,NULL),
(185,0,1718626027,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(186,0,1718626393,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"35\"}',1,0,'','',0,'','info',NULL,NULL),
(187,0,1718626407,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(188,0,1718626704,1,1,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Since we  started work in 1890\",\"table\":\"tt_content\",\"uid\":3,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW6670289387939925502554','',0,'','info',NULL,NULL),
(189,0,1718626713,1,3,2,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Welcome\\r\\n                            \\r\\n                        \\r\\n                                                    \\r\\n                        \\r\\n                            \\r\\n                         ...\",\"table\":\"tt_content\",\"uid\":2,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(190,0,1718626813,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"dengram\",\"destination\":\"\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(191,0,1718626881,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"large-pic.jpg\",\"destination\":\"\\/dengram\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(192,0,1718626917,1,1,4,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"image1\",\"table\":\"tt_content\",\"uid\":4,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW667029a605004575079441','',0,'','info',NULL,NULL),
(193,0,1718626917,1,1,1,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"large-pic.jpg\",\"table\":\"sys_file_reference\",\"uid\":1,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW66702a4beb739006463430','',0,'','info',NULL,NULL),
(194,0,1718626917,1,2,4,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"image1\",\"table\":\"tt_content\",\"uid\":4,\"history\":0}',1,0,'','',0,'','info',NULL,NULL),
(195,0,1718627007,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(196,0,1718627127,1,3,1,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"large-pic.jpg\",\"table\":\"sys_file_reference\",\"uid\":1,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(197,0,1718627127,1,3,4,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"image1\",\"table\":\"tt_content\",\"uid\":4,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(198,0,1718627138,1,1,5,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Welcome to intoriza\\r\\n                                        \\r\\n                                    \\r\\n                                    Since we  started work in 1890\\r\\n                               ...\",\"table\":\"tt_content\",\"uid\":5,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW66702b3d2a47e245453124','',0,'','info',NULL,NULL),
(199,0,1718627198,1,1,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"img1\",\"table\":\"tt_content\",\"uid\":6,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW66702b4987018442816600','',0,'','info',NULL,NULL),
(200,0,1718627198,1,1,2,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"large-pic.jpg\",\"table\":\"sys_file_reference\",\"uid\":2,\"pageTitle\":\"dengram\",\"pid\":1}',1,0,'NEW66702b528220e129108118','',0,'','info',NULL,NULL),
(201,0,1718627198,1,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"img1\",\"table\":\"tt_content\",\"uid\":6,\"history\":0}',1,0,'','',0,'','info',NULL,NULL),
(202,0,1718627206,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(203,0,1718627989,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(204,0,1718628018,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(205,0,1718628494,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(206,0,1718628628,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(207,0,1718630698,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(208,0,1718630923,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(209,0,1718631115,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(210,0,1718631148,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(211,0,1718631204,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(212,0,1718631969,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(213,0,1718632025,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(214,0,1718632215,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(215,0,1718633706,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"45\"}',1,0,'','',0,'','info',NULL,NULL),
(216,0,1718633913,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"46\"}',1,0,'','',0,'','info',NULL,NULL),
(217,0,1718634031,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"47\"}',1,0,'','',0,'','info',NULL,NULL),
(218,0,1718634241,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Since we started work in 1890\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"48\"}',1,0,'','',0,'','info',NULL,NULL),
(219,0,1718634397,1,1,7,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Welcome to intoriza\\r\\n                                        \\r\\n                                    \\r\\n                                    Since we  started work in 1890\",\"table\":\"tt_content\",\"uid\":7,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW6670478ce231b801911855','',0,'','info',NULL,NULL),
(220,0,1718634562,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(221,0,1718634623,1,2,3,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib...\",\"table\":\"tt_content\",\"uid\":3,\"history\":\"50\"}',1,0,'','',0,'','info',NULL,NULL),
(222,0,1718634626,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(223,0,1718636170,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(224,0,1718637285,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(225,0,1718637348,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(226,0,1718637577,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(227,0,1718637700,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(228,0,1718637775,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(229,0,1718637786,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(230,0,1718638002,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(231,0,1718638145,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(232,0,1718638247,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"welcome-slider\",\"destination\":\"\\/dengram\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(233,0,1718638261,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"large-pic.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(234,0,1718638349,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(235,0,1718638421,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(236,0,1718638526,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(237,0,1718638556,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(238,0,1718638622,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"1.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(239,0,1718638622,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"2.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(240,0,1718638622,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"3.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(241,0,1718638653,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(242,0,1718638736,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(243,0,1718638999,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(244,0,1718639130,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(245,0,1718639305,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(246,0,1718639357,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(247,0,1718639457,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(248,0,1718639515,1,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"img1\",\"table\":\"tt_content\",\"uid\":6,\"history\":\"51\"}',1,0,'','',0,'','info',NULL,NULL),
(249,0,1718639520,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(250,0,1718639553,1,2,5,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Welcome to intoriza\\r\\n                                        \\r\\n                                    \\r\\n                                    Since we  started work in 1890\\r\\n                               ...\",\"table\":\"tt_content\",\"uid\":5,\"history\":\"52\"}',1,0,'','',0,'','info',NULL,NULL),
(251,0,1718639559,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(252,0,1718639576,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(253,0,1718639622,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(254,0,1718639760,1,2,7,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Welcome to Dengram Alumni\\r\\n                                        \\r\\n                                    \\r\\n                                    Since we  started work in 1890\",\"table\":\"tt_content\",\"uid\":7,\"history\":\"53\"}',1,0,'','',0,'','info',NULL,NULL),
(255,0,1718639767,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(256,0,1718697263,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(257,0,1718698271,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(258,0,1718700440,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(259,0,1718700534,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(260,0,1718700604,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"1.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(261,0,1718700604,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"large-pic.jpg\",\"destination\":\"\\/dengram\\/welcome-slider\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(262,0,1718701071,1,6,0,'',0,0,'Directory \"{identifier}\" created in \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"old-boys\",\"destination\":\"\\/dengram\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(263,0,1718701259,1,1,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66714ca59c109762505944','',0,'','info',NULL,NULL),
(264,0,1718701269,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(265,0,1718701431,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"55\"}',1,0,'','',0,'','info',NULL,NULL),
(266,0,1718701434,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(267,0,1718711673,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(268,0,1718712072,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"56\"}',1,0,'','',0,'','info',NULL,NULL),
(269,0,1718712078,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(270,0,1718712223,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"57\"}',1,0,'','',0,'','info',NULL,NULL),
(271,0,1718712226,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(272,0,1718712318,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(273,0,1718712379,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"58\"}',1,0,'','',0,'','info',NULL,NULL),
(274,0,1718712430,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"59\"}',1,0,'','',0,'','info',NULL,NULL),
(275,0,1718712436,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(276,0,1718712456,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(277,0,1718713089,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(278,0,1718713159,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(279,0,1718713211,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(280,0,1718713311,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(281,0,1718713526,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(282,0,1718713854,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(283,0,1718713938,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(284,0,1718714522,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(285,0,1718714555,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(286,0,1718714799,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(287,0,1718714890,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(288,0,1718715043,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(289,0,1718715169,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(290,0,1718715356,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(291,0,1718715456,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(292,0,1718715517,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(293,0,1718715683,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"60\"}',1,0,'','',0,'','info',NULL,NULL),
(294,0,1718715686,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(295,0,1718715872,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(296,0,1718715874,1,2,8,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"The Executives\",\"table\":\"tt_content\",\"uid\":8,\"history\":\"61\"}',1,0,'','',0,'','info',NULL,NULL),
(297,0,1718715877,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(298,0,1718716056,1,1,9,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Since we started work in 1890\",\"table\":\"tt_content\",\"uid\":9,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW6671865d1c94f861679522','',0,'','info',NULL,NULL),
(299,0,1718716064,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(300,0,1718716078,1,2,9,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Since we started work in 1890\",\"table\":\"tt_content\",\"uid\":9,\"history\":\"63\"}',1,0,'','',0,'','info',NULL,NULL),
(301,0,1718716080,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(302,0,1718716094,1,3,7,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Welcome to Dengram Alumni\\r\\n                                        \\r\\n                                    \\r\\n                                    Since we  started work in 1890\",\"table\":\"tt_content\",\"uid\":7,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(303,0,1718716098,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(304,0,1718716540,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":0}',1,0,'','',0,'','info',NULL,NULL),
(305,0,1718716540,1,1,3,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":3,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW667188773e36a208479552','',0,'','info',NULL,NULL),
(306,0,1718716540,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":0}',1,0,'','',0,'','info',NULL,NULL),
(307,0,1718716709,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(308,0,1718874218,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(309,0,1718874423,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(310,0,1718874437,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(311,0,1718881499,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_news_domain_model_news\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 49. Requested URL: http://dengram.ddev.site/typo3/module/web/list?token=--AnonymizedToken--&id=1&',5,'php',0,'172.18.0.5','',-1,0,'','',0,'','error',NULL,NULL),
(312,0,1718881523,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(313,0,1718882412,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"66\"}',1,0,'','',0,'','info',NULL,NULL),
(314,0,1718882450,1,1,8,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Teams\",\"table\":\"pages\",\"uid\":8,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(315,0,1718882455,1,2,8,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Teams\",\"table\":\"pages\",\"uid\":8,\"history\":\"68\"}',8,0,'','',0,'','info',NULL,NULL),
(316,0,1718883088,1,1,9,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Member\",\"table\":\"pages\",\"uid\":9,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW_1','',0,'','info',NULL,NULL),
(317,0,1718883092,1,2,9,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Member\",\"table\":\"pages\",\"uid\":9,\"history\":\"70\"}',9,0,'','',0,'','info',NULL,NULL),
(318,0,1718883101,1,2,9,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Member\",\"table\":\"pages\",\"uid\":9,\"history\":\"71\"}',9,0,'','',0,'','info',NULL,NULL),
(319,0,1718883105,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(320,0,1718883126,1,4,9,'pages',0,0,'Moved record \"{title}\" ({table}:{uid}) on page \"{pageTitle}\" ({pid})',1,'content',4,'172.18.0.5','{\"title\":\"Member\",\"table\":\"pages\",\"uid\":9,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(321,0,1718883142,1,3,9,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Member\",\"table\":\"pages\",\"uid\":9,\"pageTitle\":\"Dengram\",\"pid\":1}',9,0,'','',0,'','info',NULL,NULL),
(322,0,1718883266,1,1,10,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Set\",\"table\":\"pages\",\"uid\":10,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW6674135a89d05300167634','',0,'','info',NULL,NULL),
(323,0,1718883272,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(324,0,1718884619,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"tm1.jpeg\",\"destination\":\"\\/dengram\\/old-boys\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(325,0,1718884662,1,1,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW667413e38088c107554856','',0,'','info',NULL,NULL),
(326,0,1718884662,1,1,4,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"tm1.jpeg\",\"table\":\"sys_file_reference\",\"uid\":4,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW667419116e94d719313597','',0,'','info',NULL,NULL),
(327,0,1718884662,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":0}',8,0,'','',0,'','info',NULL,NULL),
(328,0,1718884991,1,1,1,'sys_category',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"members\",\"table\":\"sys_category\",\"uid\":1,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66741a587849a435910932','',0,'','info',NULL,NULL),
(329,0,1718885062,1,1,2,'sys_category',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"2015\",\"table\":\"sys_category\",\"uid\":2,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66741aa1a1dc4938577807','',0,'','info',NULL,NULL),
(330,0,1718885091,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"79\"}',8,0,'','',0,'','info',NULL,NULL),
(331,0,1718885091,1,2,4,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"tm1.jpeg\",\"table\":\"sys_file_reference\",\"uid\":4,\"history\":\"80\"}',8,0,'','',0,'','info',NULL,NULL),
(332,0,1718885507,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"81\"}',8,0,'','',0,'','info',NULL,NULL),
(333,0,1718885671,1,1,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66741cf28c9d5440311862','',0,'','info',NULL,NULL),
(334,0,1718885674,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(335,0,1718886143,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"83\"}',1,0,'','',0,'','info',NULL,NULL),
(336,0,1718887548,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(337,0,1718887576,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(338,0,1718887601,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(339,0,1718887662,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"84\"}',1,0,'','',0,'','info',NULL,NULL),
(340,0,1718894772,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(341,0,1718894900,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(342,0,1718894989,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(343,0,1718895055,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(344,0,1718895410,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(345,0,1718896094,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(346,0,1718896106,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(347,0,1718897264,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"85\"}',1,0,'','',0,'','info',NULL,NULL),
(348,0,1718897292,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"86\"}',1,0,'','',0,'','info',NULL,NULL),
(349,0,1718897342,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"87\"}',1,0,'','',0,'','info',NULL,NULL),
(350,0,1718897349,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(351,0,1718897405,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"88\"}',1,0,'','',0,'','info',NULL,NULL),
(352,0,1718897436,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"89\"}',1,0,'','',0,'','info',NULL,NULL),
(353,0,1718897450,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(354,0,1718897572,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(355,0,1718897713,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(356,0,1718897923,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(357,0,1718898962,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(358,0,1718904662,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(359,0,1718904966,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(360,0,1718905420,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"tm2.jpeg\",\"destination\":\"\\/dengram\\/old-boys\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(361,0,1718905440,1,1,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW667468bbf0530292618925','',0,'','info',NULL,NULL),
(362,0,1718905440,1,1,5,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":5,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW66746a54b6b36961125953','',0,'','info',NULL,NULL),
(363,0,1718905440,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',8,0,'','',0,'','info',NULL,NULL),
(364,0,1718905442,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(365,0,1718905485,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":\"92\"}',8,0,'','',0,'','info',NULL,NULL),
(366,0,1718905485,1,2,5,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":5,\"history\":\"93\"}',8,0,'','',0,'','info',NULL,NULL),
(367,0,1718905489,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(368,0,1718905566,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(369,0,1718905719,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(370,0,1718905978,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(371,0,1718906593,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"94\"}',1,0,'','',0,'','info',NULL,NULL),
(372,0,1718906595,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(373,0,1718907043,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(374,0,1718907073,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"95\"}',1,0,'','',0,'','info',NULL,NULL),
(375,0,1718907075,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(376,0,1718907092,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"96\"}',1,0,'','',0,'','info',NULL,NULL),
(377,0,1718907094,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(378,0,1718907193,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(379,0,1718907292,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(380,0,1718907745,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(381,0,1718907822,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(382,0,1718907855,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(383,0,1718908029,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(384,0,1718908060,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"97\"}',8,0,'','',0,'','info',NULL,NULL),
(385,0,1718908065,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(386,0,1718908088,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"98\"}',8,0,'','',0,'','info',NULL,NULL),
(387,0,1718908091,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(388,0,1718908293,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(389,0,1718908319,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":\"99\"}',8,0,'','',0,'','info',NULL,NULL),
(390,0,1718908331,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":\"100\"}',8,0,'','',0,'','info',NULL,NULL),
(391,0,1718908351,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(392,0,1718908377,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":\"101\"}',8,0,'','',0,'','info',NULL,NULL),
(393,0,1718908377,1,1,6,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":6,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW667475d69a60f182018982','',0,'','info',NULL,NULL),
(394,0,1718908377,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":\"103\"}',8,0,'','',0,'','info',NULL,NULL),
(395,0,1718908377,1,3,5,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":5,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'','',0,'','info',NULL,NULL),
(396,0,1718908380,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(397,0,1718908395,1,2,2,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Austine Iheanacho\",\"table\":\"tx_news_domain_model_news\",\"uid\":2,\"history\":0}',8,0,'','',0,'','info',NULL,NULL),
(398,0,1718908395,1,2,6,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":6,\"history\":\"105\"}',8,0,'','',0,'','info',NULL,NULL),
(399,0,1718908397,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(400,0,1718908821,1,1,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Search box\",\"table\":\"tt_content\",\"uid\":11,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW6674768eca93f617670891','',0,'','info',NULL,NULL),
(401,0,1718908825,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(402,0,1718909582,1,2,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Membership\",\"table\":\"pages\",\"uid\":4,\"history\":\"107\"}',4,0,'','',0,'','info',NULL,NULL),
(403,0,1718909582,1,1,7,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":7,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW66747a85a1546249130936','',0,'','info',NULL,NULL),
(404,0,1718909582,1,2,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Membership\",\"table\":\"pages\",\"uid\":4,\"history\":\"109\"}',4,0,'','',0,'','info',NULL,NULL),
(405,0,1718909585,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(406,0,1718909646,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(407,0,1718909813,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(408,0,1718909836,1,2,4,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Membership\",\"table\":\"pages\",\"uid\":4,\"history\":\"110\"}',4,0,'','',0,'','info',NULL,NULL),
(409,0,1718909836,1,2,7,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":7,\"history\":\"111\"}',4,0,'','',0,'','info',NULL,NULL),
(410,0,1718909840,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(411,0,1718910110,1,1,12,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Members Search form\",\"table\":\"tt_content\",\"uid\":12,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW66747c839bcfa715743571','',0,'','info',NULL,NULL),
(412,0,1718910113,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(413,0,1718910531,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(414,0,1718910579,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"113\"}',4,0,'','',0,'','info',NULL,NULL),
(415,0,1718910582,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(416,0,1718910633,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(417,0,1718910661,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(418,0,1718910708,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(419,0,1718954043,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(420,0,1718954076,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"114\"}',1,0,'','',0,'','info',NULL,NULL),
(421,0,1718954081,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(422,0,1718954222,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(423,0,1718954602,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(424,0,1718954824,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(425,0,1718954838,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(426,0,1718956069,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(427,0,1718956119,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(428,0,1718956172,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(429,0,1718956270,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(430,0,1718956379,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"115\"}',1,0,'','',0,'','info',NULL,NULL),
(431,0,1718956384,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(432,0,1718956390,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"116\"}',1,0,'','',0,'','info',NULL,NULL),
(433,0,1718956392,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(434,0,1718956433,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(435,0,1718956460,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(436,0,1718956691,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(437,0,1718956725,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(438,0,1718956766,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(439,0,1718957236,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(440,0,1718957292,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(441,0,1718957421,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(442,0,1718957477,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(443,0,1718957923,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(444,0,1718958187,1,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"img1\",\"table\":\"tt_content\",\"uid\":6,\"history\":\"117\"}',1,0,'','',0,'','info',NULL,NULL),
(445,0,1718958189,1,2,6,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"img1\",\"table\":\"tt_content\",\"uid\":6,\"history\":\"118\"}',1,0,'','',0,'','info',NULL,NULL),
(446,0,1718958234,1,1,13,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"welcome bg\",\"table\":\"tt_content\",\"uid\":13,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66753873ddad7968881503','',0,'','info',NULL,NULL),
(447,0,1718958256,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(448,0,1718958339,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(449,0,1718958461,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(450,0,1718958533,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(451,0,1718958757,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(452,0,1718958799,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(453,0,1718958920,1,3,13,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"welcome bg\",\"table\":\"tt_content\",\"uid\":13,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'','',0,'','info',NULL,NULL),
(454,0,1718958957,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"121\"}',1,0,'','',0,'','info',NULL,NULL),
(455,0,1718958957,1,2,3,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":3,\"history\":\"122\"}',1,0,'','',0,'','info',NULL,NULL),
(456,0,1718959263,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(457,0,1718959363,1,2,10,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"top members\",\"table\":\"tt_content\",\"uid\":10,\"history\":\"123\"}',1,0,'','',0,'','info',NULL,NULL),
(458,0,1718959367,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(459,0,1718959435,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(460,0,1718959624,1,2,10,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Set\",\"table\":\"pages\",\"uid\":10,\"history\":\"124\"}',10,0,'','',0,'','info',NULL,NULL),
(461,0,1718959624,1,1,8,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":8,\"pageTitle\":\"Set\",\"pid\":10}',10,0,'NEW66753e047c473951427048','',0,'','info',NULL,NULL),
(462,0,1718959624,1,2,10,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Set\",\"table\":\"pages\",\"uid\":10,\"history\":\"126\"}',10,0,'','',0,'','info',NULL,NULL),
(463,0,1718959626,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(464,0,1718959675,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(465,0,1718959733,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(466,0,1718959802,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(467,0,1718959935,1,1,14,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Member Detail\",\"table\":\"tt_content\",\"uid\":14,\"pageTitle\":\"Set\",\"pid\":10}',10,0,'NEW66753f33ba706159895485','',0,'','info',NULL,NULL),
(468,0,1718960033,1,1,15,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":15,\"pageTitle\":\"Set\",\"pid\":10}',10,0,'NEW66753f793cf15812867871','',0,'','info',NULL,NULL),
(469,0,1718960036,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(470,0,1718960402,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"129\"}',8,0,'','',0,'','info',NULL,NULL),
(471,0,1718962608,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(472,0,1718962666,1,3,14,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"Member Detail\",\"table\":\"tt_content\",\"uid\":14,\"pageTitle\":\"Set\",\"pid\":10}',10,0,'','',0,'','info',NULL,NULL),
(473,0,1718962670,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(474,0,1718962838,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(475,0,1718962876,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(476,0,1718963138,1,2,1,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Anne Ezurike\",\"table\":\"tx_news_domain_model_news\",\"uid\":1,\"history\":\"131\"}',8,0,'','',0,'','info',NULL,NULL),
(477,0,1718963217,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(478,0,1718963391,1,1,0,'',0,0,'Uploading file \"{identifier}\" to \"{destination}\"',2,'file',0,'172.18.0.5','{\"identifier\":\"ptn-1.png\",\"destination\":\"\\/dengram\\/banner\\/\"}',-1,0,'','',0,'','info',NULL,NULL),
(479,0,1718963429,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(480,0,1718963590,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(481,0,1718963818,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(482,0,1718964007,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(483,0,1718964186,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(484,0,1718964212,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(485,0,1718964647,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(486,0,1718964711,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(487,0,1718964746,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(488,0,1718964954,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(489,0,1718964988,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(490,0,1718965033,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(491,0,1718965127,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(492,0,1718965316,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(493,0,1718965356,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(494,0,1718965364,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(495,0,1718965441,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(496,0,1718965597,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(497,0,1718965629,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(498,0,1718965669,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(499,0,1718965702,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(500,0,1718965748,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(501,0,1718965769,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(502,0,1718965814,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(503,0,1718965875,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(504,0,1718965923,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(505,0,1718965936,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(506,0,1718965958,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(507,0,1718965997,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(508,0,1718966115,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(509,0,1718966349,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(510,0,1718966653,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(511,0,1718966670,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(512,0,1718966684,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(513,0,1718966713,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(514,0,1718966746,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(515,0,1718967106,1,1,11,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"List\",\"table\":\"pages\",\"uid\":11,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW66755ac3ec03c543605211','',0,'','info',NULL,NULL),
(516,0,1718967150,1,2,11,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"List\",\"table\":\"pages\",\"uid\":11,\"history\":\"133\"}',11,0,'','',0,'','info',NULL,NULL),
(517,0,1718967154,1,2,11,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"List\",\"table\":\"pages\",\"uid\":11,\"history\":\"134\"}',11,0,'','',0,'','info',NULL,NULL),
(518,0,1718967281,1,1,16,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":16,\"pageTitle\":\"Membership\",\"pid\":4}',4,0,'NEW66755bba4f9fa008961559','',0,'','info',NULL,NULL),
(519,0,1718967291,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(520,0,1718967348,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(521,0,1718967410,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(522,0,1718967462,1,2,16,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":16,\"history\":\"136\"}',4,0,'','',0,'','info',NULL,NULL),
(523,0,1718967479,1,2,16,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Search result\",\"table\":\"tt_content\",\"uid\":16,\"history\":\"137\"}',4,0,'','',0,'','info',NULL,NULL),
(524,0,1718967481,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(525,0,1718967565,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(526,0,1718970612,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"138\"}',4,0,'','',0,'','info',NULL,NULL),
(527,0,1718970617,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(528,0,1718970716,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(529,0,1718970723,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(530,0,1718970775,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"139\"}',4,0,'','',0,'','info',NULL,NULL),
(531,0,1718970777,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(532,0,1718971060,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(533,0,1718971089,1,1,17,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":17,\"pageTitle\":\"List\",\"pid\":11}',11,0,'NEW66756acd58bd1666225568','',0,'','info',NULL,NULL),
(534,0,1718971096,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(535,0,1718971248,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(536,0,1718971338,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(537,0,1718971372,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(538,0,1718971455,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(539,0,1718971738,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(540,0,1718972001,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(541,0,1718972088,1,2,11,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"List\",\"table\":\"pages\",\"uid\":11,\"history\":\"141\"}',11,0,'','',0,'','info',NULL,NULL),
(542,0,1718972088,1,1,9,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"1.jpg\",\"table\":\"sys_file_reference\",\"uid\":9,\"pageTitle\":\"List\",\"pid\":11}',11,0,'NEW66756eb5c038f735360806','',0,'','info',NULL,NULL),
(543,0,1718972088,1,2,11,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"List\",\"table\":\"pages\",\"uid\":11,\"history\":\"143\"}',11,0,'','',0,'','info',NULL,NULL),
(544,0,1718972155,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"144\"}',4,0,'','',0,'','info',NULL,NULL),
(545,0,1718972157,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(546,0,1718973960,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(547,0,1718973992,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(548,0,1718974075,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(549,0,1718974116,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(550,0,1718974158,1,2,16,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Search result\",\"table\":\"tt_content\",\"uid\":16,\"history\":\"145\"}',4,0,'','',0,'','info',NULL,NULL),
(551,0,1718974160,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(552,0,1718978822,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(553,0,1718978876,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(554,0,1718978919,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(555,0,1718979555,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(556,0,1718979601,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(557,0,1718979681,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(558,0,1718979742,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(559,0,1718979885,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(560,0,1718980380,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(561,0,1718980651,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(562,0,1718980703,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(563,0,1718980803,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(564,0,1718980921,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"146\"}',4,0,'','',0,'','info',NULL,NULL),
(565,0,1718980923,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(566,0,1718980979,1,2,11,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":11,\"history\":\"147\"}',4,0,'','',0,'','info',NULL,NULL),
(567,0,1718980982,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(568,0,1718981045,1,1,18,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":18,\"pageTitle\":\"Set\",\"pid\":10}',10,0,'NEW667591ad8a908302083257','',0,'','info',NULL,NULL),
(569,0,1718981051,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(570,0,1718981059,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(571,0,1718981155,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(572,0,1718981174,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(573,0,1718982364,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(574,0,1718982445,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(575,0,1718982456,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(576,0,1718982465,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(577,0,1718982468,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(578,0,1718987021,1,1,3,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"Derrick Chimdalu\",\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW6675a7eac2a85800999301','',0,'','info',NULL,NULL),
(579,0,1718987021,1,1,10,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":10,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW6675a859eba6e425073009','',0,'','info',NULL,NULL),
(580,0,1718987021,1,2,3,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Derrick Chimdalu\",\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":0}',8,0,'','',0,'','info',NULL,NULL),
(581,0,1718987063,1,2,3,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Derrick Chimdalu\",\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"151\"}',8,0,'','',0,'','info',NULL,NULL),
(582,0,1718987063,1,1,11,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":11,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'NEW6675a9318ffd7154122141','',0,'','info',NULL,NULL),
(583,0,1718987063,1,2,3,'tx_news_domain_model_news',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Derrick Chimdalu\",\"table\":\"tx_news_domain_model_news\",\"uid\":3,\"history\":\"153\"}',8,0,'','',0,'','info',NULL,NULL),
(584,0,1718987063,1,3,10,'sys_file_reference',0,0,'Record \"{title}\" ({table}:{uid}) was deleted from page \"{pageTitle}\" ({pid})',1,'content',0,'172.18.0.5','{\"title\":\"tm2.jpeg\",\"table\":\"sys_file_reference\",\"uid\":10,\"pageTitle\":\"Teams\",\"pid\":8}',8,0,'','',0,'','info',NULL,NULL),
(585,0,1718987124,1,2,1,'pages',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Dengram\",\"table\":\"pages\",\"uid\":1,\"history\":\"155\"}',1,0,'','',0,'','info',NULL,NULL),
(586,0,1718987126,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(587,0,1718987204,1,2,9,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.5','{\"title\":\"Since we started work in 1925\",\"table\":\"tt_content\",\"uid\":9,\"history\":\"156\"}',1,0,'','',0,'','info',NULL,NULL),
(588,0,1718987206,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(589,0,1718987476,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.5','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(590,0,1719324777,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(591,0,1719324795,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(592,0,1719829512,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(593,0,1719927306,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(594,0,1720016981,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(595,0,1720090297,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.18.0.6','[\"t3-admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(596,0,1722844100,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.18.0.6','[\"t3-admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(597,0,1722844108,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.18.0.6','[\"t3-admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(598,0,1722844166,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user',2,'172.18.0.6','[\"t3-admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(599,0,1722844222,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(600,0,1722844480,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(601,0,1722844517,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(602,0,1722844615,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(603,0,1723052267,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(604,0,1723052267,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1301827270: Failed to restore the session token from the registry. | UnexpectedValueException thrown in file /var/www/html/vendor/typo3/cms-core/Classes/FormProtection/BackendFormProtection.php in line 145. Requested URL: https://dengram.ddev.site/typo3/ajax/login',5,'php',0,'172.18.0.6','',-1,0,'','',0,'','error',NULL,NULL),
(605,0,1723052282,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(606,0,1723120833,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(607,0,1723129580,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(608,0,1723189512,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(609,0,1723201945,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(610,0,1723461391,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(611,0,1723542520,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.5','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(612,0,1724679388,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(613,0,1724679419,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(614,0,1724684009,1,1,0,'tt_content',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content',12,'172.18.0.6','{\"reason\":\"Unknown column \'icon_type\' in \'field list\'\",\"table\":\"tt_content\",\"uid\":\"NEW66cc96d6abf77709618328\"}',-1,0,'','',0,'','info',NULL,NULL),
(615,0,1724684137,1,1,19,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"Some Text\",\"table\":\"tt_content\",\"uid\":19,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66cc97591dd34297479606','',0,'','info',NULL,NULL),
(616,0,1724684140,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(617,0,1724684419,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(618,0,1724684888,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(619,0,1724685244,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"158\"}',1,0,'','',0,'','info',NULL,NULL),
(620,0,1724685247,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(621,0,1724685457,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(622,0,1724685696,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(623,0,1724685748,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(624,0,1724685968,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(625,0,1724686985,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(626,0,1724686994,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(627,0,1724687021,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"159\"}',1,0,'','',0,'','info',NULL,NULL),
(628,0,1724687026,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(629,0,1724687616,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(630,0,1724744923,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(631,0,1724744941,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"160\"}',1,0,'','',0,'','info',NULL,NULL),
(632,0,1724744944,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(633,0,1724745019,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(634,0,1724745047,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(635,0,1724745061,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(636,0,1724745104,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(637,0,1724745152,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(638,0,1724745173,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(639,0,1724745403,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"161\"}',1,0,'','',0,'','info',NULL,NULL),
(640,0,1724745406,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"pages\"}',-1,0,'','',0,'','info',NULL,NULL),
(641,0,1724745463,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"162\"}',1,0,'','',0,'','info',NULL,NULL),
(642,0,1724745466,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default',0,'172.18.0.6','{\"username\":\"t3admin\",\"command\":\"all\"}',-1,0,'','',0,'','info',NULL,NULL),
(643,0,1724745800,1,2,1,'sys_template',0,0,'Record \"{title}\" ({table}:{uid}) was updated',1,'content',10,'172.18.0.6','{\"title\":\"dengram package\",\"table\":\"sys_template\",\"uid\":1,\"history\":\"163\"}',1,0,'','',0,'','info',NULL,NULL),
(644,0,1724745874,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(645,0,1724753057,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(646,0,1724753571,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(647,0,1724847038,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(648,0,1724847074,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(649,0,1724847786,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(650,0,1724847907,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL),
(651,0,1724859039,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,-99,'','',0,'','info',NULL,NULL),
(652,0,1724859121,1,1,20,'tt_content',0,0,'Record \"{title}\" ({table}:{uid}) was inserted on page \"{pageTitle}\" ({pid})',1,'content',10,'172.18.0.6','{\"title\":\"[No title]\",\"table\":\"tt_content\",\"uid\":20,\"pageTitle\":\"Dengram\",\"pid\":1}',1,0,'NEW66cf42b39c0d4221598231','',0,'','info',NULL,NULL),
(653,0,1724859610,1,2,0,'',0,0,'User %s logged out from TYPO3 Backend',255,'user',1,'172.18.0.6','[\"t3admin\"]',-1,0,'','',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`fields`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) NOT NULL DEFAULT '',
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recuid` int(11) NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `ref_table` varchar(255) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`(100),`recuid`),
  KEY `lookup_uid` (`ref_table`(100),`ref_uid`),
  KEY `lookup_string` (`ref_string`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('0bc75fc48a18f1b7592b49955076fe97','sys_file',6,'storage','','','',0,0,'sys_file_storage',1,''),
('15597f65d7df3a40d1e792514c91c69f','sys_file',10,'storage','','','',0,0,'sys_file_storage',1,''),
('15c7256ae9855ac865059bccec380298','tx_news_domain_model_news',1,'fal_media','','','',0,0,'sys_file_reference',4,''),
('170b08d28390b7c815c3f7b30d985171','pages',11,'media','','','',0,0,'sys_file_reference',9,''),
('1c9b8784c1518ef7b22704c4fc698ca9','sys_file',2,'storage','','','',0,0,'sys_file_storage',1,''),
('233b22ed37363c588a3905e77739a694','tx_news_domain_model_news',2,'fal_media','','','',0,0,'sys_file_reference',6,''),
('24d47b29aa969cf4db8635e76dd1c386','sys_file',3,'storage','','','',0,0,'sys_file_storage',1,''),
('305cb83a197706a88ff5a3598047ed6c','tt_content',10,'pi_flexform','additional/lDEF/settings.backPid/vDEF/','','',0,0,'pages',1,''),
('3274f8ce9997f77e32b61e48254f8a6b','pages',10,'media','','','',0,0,'sys_file_reference',8,''),
('4c5fb10ebfe9591f12604dfaf698f483','sys_file_reference',9,'uid_local','','','',0,0,'sys_file',7,''),
('519abab77a1c75ccecfd3667daa77b31','tt_content',6,'image','','','',0,0,'sys_file_reference',2,''),
('58ed14cd0c8ec32cac7528dee66ec795','sys_file_reference',3,'uid_local','','','',0,0,'sys_file',7,''),
('692e129d0a6ae1105f43e3627f14e64d','sys_file',8,'storage','','','',0,0,'sys_file_storage',1,''),
('6c4ee64780250fea87ff46489259e3da','sys_file_reference',8,'uid_local','','','',0,0,'sys_file',7,''),
('749b0771828793d3e3eba1372852a7a8','sys_file',2,'metadata','','','',0,0,'sys_file_metadata',2,''),
('791d3f9d43dcbfa78cd49dd8258caa09','sys_file',5,'storage','','','',0,0,'sys_file_storage',1,''),
('794ad2a1eccf7d36eadc4455469c1147','sys_category',2,'items','','','',1,0,'tx_news_domain_model_news',2,''),
('7a1c4431c143431f92bb6ef71f4a3831','tt_content',10,'pi_flexform','additional/lDEF/settings.detailPid/vDEF/','','',0,0,'pages',10,''),
('7aea9e7161a77a3726e70829cce44875','sys_category',2,'parent','','','',0,0,'sys_category',1,''),
('83e547bebf151c6d932f7bdc5487ef64','sys_file',9,'storage','','','',0,0,'sys_file_storage',1,''),
('8a1353cb76c0a3540110caed8c5dec14','tx_news_domain_model_news',3,'fal_media','','','',0,0,'sys_file_reference',11,''),
('93004573d1d006a130ef069b9f27b1f9','sys_file',7,'storage','','','',0,0,'sys_file_storage',1,''),
('976bde2c66528fe228f527ed842f4b18','sys_file_reference',2,'uid_local','','','',0,0,'sys_file',2,''),
('9d0f69bef8b5d48f35409b4a8b99ebea','tt_content',10,'pi_flexform','sDEF/lDEF/settings.selectedList/vDEF/','','',1,0,'tx_news_domain_model_news',1,''),
('a13c329b97229151e484e0ffe41e0efa','sys_file_reference',11,'uid_local','','','',0,0,'sys_file',9,''),
('a5615cca7a6e779c2ed7eeda9a5d72a4','tt_content',11,'pi_flexform','additional/lDEF/settings.listPid/vDEF/','','',0,0,'pages',10,''),
('a87344067faefa9fb880a404a4790d94','sys_file',9,'metadata','','','',0,0,'sys_file_metadata',9,''),
('bab37143de5339e474516691bf0c5857','sys_file',4,'storage','','','',0,0,'sys_file_storage',1,''),
('ce65ac97d7c747d91080f849e0d69b2c','sys_category',2,'items','','','',0,0,'tx_news_domain_model_news',1,''),
('cf8c8651709688a5944fb6700e987f5b','sys_category',1,'items','','','',0,0,'tt_content',11,''),
('d381cdb1f6e0b5e410f6259ff475f4fb','pages',1,'media','','','',0,0,'sys_file_reference',3,''),
('d9b22b225391e9c63faefe4c394612b2','sys_file_reference',6,'uid_local','','','',0,0,'sys_file',9,''),
('e34875ad16da9006119fd47156353a38','sys_file_reference',4,'uid_local','','','',0,0,'sys_file',8,''),
('ef640495b827e0bc0296b176d43b0f7d','pages',4,'media','','','',0,0,'sys_file_reference',7,''),
('f83833412c303a33a9ff9f34af47161a','tt_content',10,'pi_flexform','sDEF/lDEF/settings.selectedList/vDEF/','','',0,0,'tx_news_domain_model_news',2,''),
('fd882ca476fb7281bd9b8ec79a750032','sys_file_reference',7,'uid_local','','','',0,0,'sys_file',7,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendGroupsExplicitAllowDenyMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendModulePermissionMigration','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Install\\Updates\\BackendUserLanguageMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Install\\Updates\\FeLoginModeExtractionUpdate','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Install\\Updates\\CollectionsExtractionUpdate','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Install\\Updates\\MigrateSiteSettingsConfigUpdate','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Install\\Updates\\PasswordPolicyForFrontendUsersUpdate','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Install\\Updates\\ShortcutRecordsMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SvgFilesSanitization','i:1;'),
(10,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileCollectionIdentifierMigration','i:1;'),
(11,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysFileMountIdentifierMigration','i:1;'),
(12,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogChannel','i:1;'),
(13,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysLogSerializationUpdate','i:1;'),
(14,'installUpdate','TYPO3\\CMS\\Install\\Updates\\SysTemplateNoWorkspaceMigration','i:1;'),
(15,'installUpdateRows','rowUpdatersDone','a:4:{i:0;s:66:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\L18nDiffsourceToJsonMigration\";i:1;s:77:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceMovePlaceholderRemovalMigration\";i:2;s:76:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\WorkspaceNewPlaceholderRemovalMigration\";i:3;s:69:\"TYPO3\\CMS\\Install\\Updates\\RowUpdater\\SysRedirectRootPageMoveMigration\";}'),
(17,'extensionDataImport','typo3/cms-core/ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','typo3/cms-extbase/ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','typo3/cms-fluid/ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','typo3/cms-install/ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','typo3/cms-backend/ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','typo3/cms-frontend/ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','typo3/cms-dashboard/ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','typo3/cms-fluid-styled-content/ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','typo3/cms-filelist/ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','typo3/cms-impexp/ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','typo3/cms-form/ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','typo3/cms-seo/ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','typo3/cms-setup/ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','typo3/cms-rte-ckeditor/ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','typo3/cms-belog/ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','typo3/cms-beuser/ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','typo3/cms-extensionmanager/ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','typo3/cms-felogin/ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','typo3/cms-info/ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','typo3/cms-reactions/ext_tables_static+adt.sql','s:0:\"\";'),
(37,'extensionDataImport','typo3/cms-sys-note/ext_tables_static+adt.sql','s:0:\"\";'),
(38,'extensionDataImport','typo3/cms-t3editor/ext_tables_static+adt.sql','s:0:\"\";'),
(39,'extensionDataImport','typo3/cms-tstemplate/ext_tables_static+adt.sql','s:0:\"\";'),
(40,'extensionDataImport','typo3/cms-viewpage/ext_tables_static+adt.sql','s:0:\"\";'),
(41,'extensionDataImport','typo3/cms-webhooks/ext_tables_static+adt.sql','s:0:\"\";'),
(42,'extensionDataImport','dengram/dengram-package/ext_tables_static+adt.sql','s:32:\"cd57437a5f633b70b114c94c126c4e1f\";'),
(43,'extensionDataImport','georgringer/news/ext_tables_static+adt.sql','s:0:\"\";'),
(44,'extensionDataImport','friendsoftypo3/extension-builder/ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `include_static_file` text DEFAULT NULL,
  `constants` text DEFAULT NULL,
  `config` text DEFAULT NULL,
  `basedOn` tinytext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `static_file_mode` smallint(5) unsigned NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
INSERT INTO `sys_template` VALUES
(1,1,1724745800,1718362673,0,0,0,0,256,'',0,'dengram package',1,3,'EXT:dengram_package/Configuration/TypoScript,EXT:news/Configuration/TypoScript,EXT:bootstrap_package/Configuration/TypoScript/ContentElement','','','',0,3,0);
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `name` varchar(100) NOT NULL DEFAULT '',
  `url` varchar(2048) NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `verify_ssl` int(11) NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL COMMENT '(DC2Type:json)' CHECK (json_valid(`additional_headers`)),
  `identifier` varchar(36) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rowDescription` text DEFAULT NULL,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `bodytext` mediumtext DEFAULT NULL,
  `bullets_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned NOT NULL DEFAULT 0,
  `imageorient` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `records` text DEFAULT NULL,
  `pages` text DEFAULT NULL,
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `header_link` varchar(1024) NOT NULL DEFAULT '',
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `header_layout` varchar(30) NOT NULL DEFAULT '0',
  `list_type` varchar(255) NOT NULL DEFAULT '',
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 0,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` text DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imageheight` int(10) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` mediumtext DEFAULT NULL,
  `accessibility_title` varchar(30) NOT NULL DEFAULT '',
  `accessibility_bypass` smallint(5) unsigned NOT NULL DEFAULT 0,
  `accessibility_bypass_text` varchar(30) NOT NULL DEFAULT '',
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_caption` varchar(255) DEFAULT NULL,
  `table_delimiter` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_enclosure` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_header_position` smallint(5) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `selected_categories` longtext DEFAULT NULL,
  `date` int(11) NOT NULL DEFAULT 0,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `tx_news_related_news` int(11) NOT NULL DEFAULT 0,
  `header_class` varchar(60) NOT NULL DEFAULT '',
  `subheader_class` varchar(60) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `aspect_ratio` varchar(255) NOT NULL DEFAULT '1.3333333333333',
  `items_per_page` int(10) unsigned DEFAULT 10,
  `readmore_label` varchar(255) NOT NULL DEFAULT '',
  `quote_source` varchar(255) NOT NULL DEFAULT '',
  `quote_link` varchar(1024) NOT NULL DEFAULT '',
  `panel_class` varchar(60) NOT NULL DEFAULT 'default',
  `file_folder` text DEFAULT NULL,
  `icon` varchar(255) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `icon_position` varchar(255) NOT NULL DEFAULT '',
  `icon_size` varchar(60) NOT NULL DEFAULT 'default',
  `icon_type` varchar(60) NOT NULL DEFAULT 'default',
  `icon_color` varchar(255) NOT NULL DEFAULT '',
  `icon_background` varchar(255) NOT NULL DEFAULT '',
  `external_media_title` varchar(255) NOT NULL DEFAULT '',
  `external_media_source` varchar(1024) NOT NULL DEFAULT '',
  `external_media_ratio` varchar(10) NOT NULL DEFAULT '',
  `tx_bootstrappackage_card_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_carousel_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_accordion_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_icon_group_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_tab_item` int(10) unsigned DEFAULT 0,
  `tx_bootstrappackage_timeline_item` int(10) unsigned DEFAULT 0,
  `frame_layout` varchar(255) NOT NULL DEFAULT 'default',
  `frame_options` varchar(255) NOT NULL DEFAULT '',
  `background_color_class` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  `subitems_header_layout` int(10) unsigned NOT NULL DEFAULT 4,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `language` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `index_newscontent` (`tx_news_related_news`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,'',1,1718362744,1718362706,1,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'text','Welcome','','<p>Hello world</p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(2,'',1,1718626713,1718370759,1,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'html','','','<!-- INNER PAGE BANNER -->\r\n            <div class=\"wt-bnr-inr overlay-wraper bg-center\"  style=\"background-image:url(images/banner/1.jpg);\">\r\n            	<div class=\"overlay-main bg-black opacity-07\"></div>\r\n                <div class=\"container\">\r\n                    <div class=\"wt-bnr-inr-entry\">\r\n                    	<div class=\"banner-title-outer\">\r\n                        	<div class=\"banner-title-name\">\r\n                        		<h2 class=\"text-white\">Welcome</h2>\r\n                            </div>\r\n                        </div>\r\n                        <!-- BREADCRUMB ROW -->                            \r\n                        \r\n                            <div>\r\n                                <ul class=\"wt-breadcrumb breadcrumb-style-2\">\r\n                                    <li><a href=\"index.html\">Home</a></li>\r\n                                    <li>About 1</li>\r\n                                </ul>\r\n                            </div>\r\n                        \r\n                        <!-- BREADCRUMB ROW END -->                        \r\n                    </div>\r\n                </div>\r\n            </div>\r\n            <!-- INNER PAGE BANNER END -->\r\n            \r\n            <!-- WELCOME SECTION START -->\r\n            <div class=\"section-full p-t80 p-b50 bg-white\">\r\n                <div class=\"container\">\r\n                    <div class=\"section-content\">\r\n                    	<div class=\"row\">\r\n                        	<div class=\"col-lg-7 col-md-12 m-b30\">\r\n                            	<div class=\"welcome-carousel-outer m-b60\">\r\n                                	<div class=\"welcome-bg-block clearfix\">\r\n                                        <div class=\"welcome-carousel-1 \">\r\n                                            <div class=\"owl-carousel home-carousel-1 owl-btn-bottom-left\">\r\n                                                <!-- COLUMNS 1 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/1.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 2 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/2.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 3 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"owl-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/3.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 4 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/4.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 5 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/5.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                           </div>\r\n                                        </div>                                 \r\n                                   </div>\r\n                               </div>\r\n                            </div>\r\n                    		<div class=\"col-lg-5 col-md-12 m-b30\">\r\n                                <!-- TITLE START -->\r\n                                <div class=\"section-head\">\r\n                                	<div class=\"wt-separator-outer separator-left\">\r\n                                		<div class=\"wt-separator\">\r\n                                            <span class=\"site-text-primary text-uppercase sep-line-one \">Welcome to Dengram Alumni</span>\r\n                                        </div>\r\n                                    </div>\r\n                                    <h2>Since we <br> started work in 1890</h2>\r\n                                </div>\r\n                                <!-- TITLE END -->                            \r\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.</p>\r\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,</p>\r\n                                 <a href=\"project-detail.html\" class=\"site-button m-t15 m-b15\">Read More</a>\r\n                            </div>                            \r\n                        </div>\r\n                        \r\n                    </div>\r\n                </div>\r\n            </div>   \r\n            <!-- WELCOME  SECTION END --> \r\n            \r\n            <!-- WHAT WE DO SECTION START -->\r\n            <div class=\"section-full p-t80 p-b50 bg-gray\">\r\n                <div class=\"container\">\r\n                    <!-- TITLE START -->\r\n                    <div class=\"section-head text-center\">\r\n                        <div class=\"wt-separator-outer separator-center\">\r\n                            <div class=\"wt-separator\">\r\n                                <span class=\"site-text-primary text-uppercase sep-line-one \">what you prefer</span>\r\n                            </div>\r\n                        </div>\r\n                        <h2>What we do</h2>\r\n                    </div>\r\n                    <!-- TITLE END -->\r\n                    <div class=\"section-content\">\r\n                    	<div class=\"row\">\r\n                            <div class=\"col-lg-3 col-md-6 m-b30\">\r\n                            	<div class=\"hover-box-effect  v-icon-effect\">\r\n                                    <div class=\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\">\r\n                                        <div class=\"icon-lg site-text-primary m-b20\">\r\n                                            <span class=\"icon-cell site-text-primary\"><i class=\"v-icon flaticon-sketch\"></i></span>\r\n                                        </div>\r\n                                        <div class=\"icon-content text-black\">\r\n                                            <h4 class=\"wt-tilte m-b25\">Planning</h4>\r\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.</p>\r\n                                            <a href=\"project-detail.html\" class=\"site-button-link\" data-hover=\"Read More\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    \r\n                                </div>\r\n                            </div>                          \r\n                            <div class=\"col-lg-3 col-md-6 m-b30\">\r\n                                <div class=\"hover-box-effect v-icon-effect\">\r\n                                    <div class=\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\">\r\n                                        <div class=\"icon-lg site-text-primary m-b20\">\r\n                                            <span class=\"icon-cell site-text-primary\"><i class=\"v-icon flaticon-window\"></i></span>\r\n                                        </div>\r\n                                        <div class=\"icon-content text-black\">\r\n                                            <h4 class=\"wt-tilte m-b25\">interior</h4>\r\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.</p>\r\n                                            <a href=\"project-detail.html\" class=\"site-button-link\" data-hover=\"Read More\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    \r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-6 m-b30\">\r\n                            	<div class=\"hover-box-effect v-icon-effect\">\r\n                                    <div class=\"wt-icon-box-wraper center p-lr30  p-b50 p-t50  bg-white\">\r\n                                        <div class=\"icon-lg site-text-primary m-b20\">\r\n                                            <span class=\"icon-cell site-text-primary\"><i class=\"v-icon flaticon-window-5\"></i></span>\r\n                                        </div>\r\n                                        <div class=\"icon-content text-black\">\r\n                                            <h4 class=\"wt-tilte m-b25\">Exterior</h4>\r\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.</p>\r\n                                            <a href=\"project-detail.html\" class=\"site-button-link\" data-hover=\"Read More\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    \r\n                                </div>\r\n                            </div>\r\n                            <div class=\"col-lg-3 col-md-6 m-b30\">\r\n                            	<div class=\"hover-box-effect v-icon-effect\">\r\n                                    <div class=\"wt-icon-box-wraper center p-lr30  p-b50 p-t50 bg-white\">\r\n                                        <div class=\"icon-lg site-text-primary m-b20\">\r\n                                            <span class=\"icon-cell site-text-primary\"><i class=\"v-icon flaticon-plant\"></i></span>\r\n                                        </div>\r\n                                        <div class=\"icon-content text-black\">\r\n                                            <h4 class=\"wt-tilte m-b25\">Decoration</h4>\r\n                                            <p>Lorem ipsum dolor sit amet, iusto quando  vocibus te vim no mea.</p>\r\n                                            <a href=\"project-detail.html\" class=\"site-button-link\" data-hover=\"Read More\">Read More</a>\r\n                                        </div>\r\n                                    </div>\r\n                                    \r\n                                 </div>\r\n                            </div>                          \r\n                        </div>                                \r\n                    </div>\r\n                </div>  \r\n            </div>   \r\n            <!-- WHAT WE DO  SECTION END --> \r\n            \r\n            <!-- OUR TEAM START -->\r\n            <div class=\"section-full small-device p-t80 p-b50 bg-white\">\r\n				<div class=\"container\">\r\n\r\n                    <!-- TITLE START -->\r\n                    <div class=\"section-head text-center\">\r\n                        <div class=\"wt-separator-outer separator-center\">\r\n                            <div class=\"wt-separator\">\r\n                                <span class=\"site-text-primary text-uppercase sep-line-one \">Our Best Team</span>\r\n                            </div>\r\n                        </div>\r\n                        <h2>Our Team</h2>\r\n                    </div>\r\n                    <!-- TITLE END --> \r\n     \r\n                    <!-- IMAGE CAROUSEL START -->\r\n                    <div class=\"row d-flex justify-content-center\">\r\n                        <div class=\"col-lg-4 col-md-6 m-b30\">\r\n                            <div class=\"our-team-one\">\r\n                                    <div class=\"team-bg\">\r\n                                        <h4>Jack Semper</h4>\r\n                                    </div>\r\n                                    <div class=\"team-img\">\r\n                                        <img src=\"images/our-team5/pic1.jpg\" alt=\"\" />\r\n                                        <ul class=\"list-unstyled\">\r\n                                            <li><a href=\"javascript:void(0);\" class=\"fa fa-google\"></a></li>\r\n                                            <li><a href=\"javascript:void(0);\" class=\"fa fa-rss\"></a></li>\r\n                                            <li><a href=\"javascript:void(0);\" class=\"fa fa-facebook\"></a></li>\r\n                                            <li><a href=\"javascript:void(0);\" class=\"fa fa-twitter\"></a></li>\r\n                                        </ul>\r\n                                    </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-lg-4 col-md-6 m-b30\">\r\n                            <div class=\"our-team-one\">\r\n                                    <div class=\"team-bg\">\r\n                                    <h4>Philip Wilson</h4>\r\n                                    </div>\r\n                                    <div class=\"team-img\">\r\n                                        <img src=\"images/our-team5/pic2.jpg\" alt=\"\" />\r\n                                        <ul class=\"list-unstyled\">\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-google\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-rss\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-facebook\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-twitter\"></a></li>\r\n                                    </ul>\r\n                                    </div>\r\n                            </div>\r\n                        </div>\r\n                        <div class=\"col-lg-4 col-md-6 m-b30\">\r\n                            <div class=\"our-team-one\">\r\n                                    <div class=\"team-bg\">\r\n                                    <h4>Amanda Rich</h4>\r\n                                    </div>\r\n                                    <div class=\"team-img\">\r\n                                        <img src=\"images/our-team5/pic3.jpg\" alt=\"\" />\r\n                                        <ul class=\"list-unstyled\">\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-google\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-rss\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-facebook\"></a></li>\r\n                                        <li><a href=\"javascript:void(0);\" class=\"fa fa-twitter\"></a></li>\r\n                                    </ul>\r\n                                    </div>\r\n                            </div>\r\n                        </div>\r\n                    </div>\r\n\r\n                </div>\r\n                \r\n             </div>   \r\n            <!-- OUR TEAM END -->',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(3,'',1,1718634623,1718626704,0,0,0,0,'',128,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'text','','','<p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.</p>\r\n<p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,</p>\r\n<p><a class=\"site-button m-t15 m-b15\" href=\"project-detail.html\">Read More</a></p>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,2,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(4,'',1,1718627127,1718626917,1,0,0,0,'',64,0,0,0,0,NULL,0,'',0,0,0,0,'image','image1','',NULL,0,0,0,0,1,0,1,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(5,'',1,1718639553,1718627138,0,1,0,0,'',64,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'html','','','<!-- WELCOME SECTION START -->\r\n            <div class=\"section-full p-t80 p-b50 bg-white\">\r\n                <div class=\"container\">\r\n                    <div class=\"section-content\">\r\n                    	<div class=\"row\">\r\n                        	<div class=\"col-lg-7 col-md-12 m-b30\">\r\n                            	<div class=\"welcome-carousel-outer m-b60\">\r\n                                	<div class=\"welcome-bg-block clearfix\">\r\n                                        <div class=\"welcome-carousel-1 \">\r\n                                            <div class=\"owl-carousel home-carousel-1 owl-btn-bottom-left\">\r\n                                                <!-- COLUMNS 1 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/1.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 2 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/2.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 3 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"owl-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/3.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 4 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/4.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                                <!-- COLUMNS 5 -->\r\n                                                <div class=\"item\">\r\n                                                    <div class=\"ow-img\">\r\n                                                        <a href=\"project-detail.html\"><img src=\"images/welcome-slider/5.jpg\" alt=\"\"></a>\r\n                                                    </div>\r\n                                                </div>\r\n                                           </div>\r\n                                        </div>                                 \r\n                                   </div>\r\n                               </div>\r\n                            </div>\r\n                    		<div class=\"col-lg-5 col-md-12 m-b30\">\r\n                                <!-- TITLE START -->\r\n                                <div class=\"section-head\">\r\n                                	<div class=\"wt-separator-outer separator-left\">\r\n                                		<div class=\"wt-separator\">\r\n                                            <span class=\"site-text-primary text-uppercase sep-line-one \">Welcome to intoriza</span>\r\n                                        </div>\r\n                                    </div>\r\n                                    <h2>Since we <br> started work in 1890</h2>\r\n                                </div>\r\n                                <!-- TITLE END -->                            \r\n                                <p>It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n                                 The point of using Lorem Ipsum is that it has a more-or-less normal distrib  ution of letters, as opposed to using \'Content here, content here.</p>\r\n                                <p>Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text,</p>\r\n                                 <a href=\"project-detail.html\" class=\"site-button m-t15 m-b15\">Read More</a>\r\n                            </div>                            \r\n                        </div>\r\n                        \r\n                    </div>\r\n                </div>\r\n            </div>   \r\n            <!-- WELCOME  SECTION END --> ',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(6,'',1,1718958189,1718627198,0,1,0,0,'',32,0,0,0,0,NULL,0,'{\"hidden\":\"\"}',0,0,0,0,'image','img1','',NULL,0,0,0,0,1,0,1,1,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(7,'',1,1718716094,1718634397,1,0,0,0,'',16,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"bodytext\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'html','','','<div class=\"section-head\">\r\n                                	<div class=\"wt-separator-outer separator-left\">\r\n                                		<div class=\"wt-separator\">\r\n                                            <span class=\"site-text-primary text-uppercase sep-line-one \">Welcome to Dengram Alumni</span>\r\n                                        </div>\r\n                                    </div>\r\n                                    <h2>Since we <br> started work in 1890</h2>\r\n                                </div>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,2,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(8,'',1,1718715874,1718701259,0,0,0,0,'',8,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','The Executives','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Our Old Boys','',0,'2','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(9,'',1,1718987204,1718716056,0,0,0,0,'',4,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'header','Since we started work in 1925','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,2,'Welcome to Dengram Alumni','',0,'2','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(10,'',1,1718959363,1718885671,0,0,0,0,'',20,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'news_newsselectedlist','top members','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.selectedList\">\n                    <value index=\"vDEF\">2,1</value>\n                </field>\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(11,'',4,1718980979,1718908821,0,0,0,0,'',256,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'news_newssearchform','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\">10</value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,1,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(12,'',4,1718910110,1718910110,0,0,0,0,'',128,0,0,0,0,NULL,0,'',0,0,0,0,'header','','center',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'Members Search form','',0,'2','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(13,'',1,1718958920,1718958234,1,0,0,0,'',2,0,0,0,0,NULL,0,'',0,0,0,0,'html','welcome bg','','<div class=\"welcome-carousel-outer m-b60\">\r\n                      <div class=\"welcome-bg-block clearfix\">\r\n                           <div class=\"welcome-carousel-1 \">\r\n                               <div class=\"owl-carousel home-carousel-1 owl-btn-bottom-left\">\r\n                                   <!-- COLUMNS 1 -->\r\n                                   <div class=\"item\">\r\n                                       <div class=\"ow-img\">\r\n                                           <a href=\"#\"><img src=\"/fileadmin/dengram/welcome-slider/1.jpg\" alt=\"\"></a>\r\n                                       </div>\r\n                                   </div>\r\n                                   \r\n                              </div>\r\n                           </div>                                 \r\n                      </div>\r\n                  </div>',0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,1,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(14,'',10,1718962666,1718959935,1,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'header','Member Detail','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(15,'',10,1718960033,1718960033,0,0,0,0,'',512,0,0,0,0,NULL,0,'',0,0,0,0,'news_newsdetail','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.singleNews\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(16,'',4,1718974158,1718967281,0,0,0,0,'',512,0,0,0,0,NULL,0,'{\"CType\":\"\",\"colPos\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_position\":\"\",\"date\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"\",\"layout\":\"\",\"frame_class\":\"\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"\",\"linkToTop\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"categories\":\"\",\"rowDescription\":\"\"}',0,0,0,0,'news_newssearchresult','Search result','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'100','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(17,'',11,1718971089,1718971089,0,0,0,0,'',256,0,0,0,0,NULL,0,'',0,0,0,0,'news_newssearchresult','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(18,'',10,1718981045,1718981045,0,0,0,0,'',768,0,0,0,0,NULL,0,'',0,0,0,0,'news_newssearchresult','','',NULL,0,0,0,0,0,0,0,2,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.orderBy\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.orderDirection\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.dateField\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categoryConjunction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.categories\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.includeSubCategories\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.archiveRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.timeRestrictionHigh\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsRestriction\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.previewHiddenRecords\">\n                    <value index=\"vDEF\">2</value>\n                </field>\n                <field index=\"settings.startingpoint\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.recursive\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"additional\">\n            <language index=\"lDEF\">\n                <field index=\"settings.detailPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.listPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.backPid\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.limit\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.offset\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.tags\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.hidePagination\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.list.paginate.itemsPerPage\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.topNewsFirst\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.excludeAlreadyDisplayedNews\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.disableOverrideDemand\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n        <sheet index=\"template\">\n            <language index=\"lDEF\">\n                <field index=\"settings.media.maxWidth\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.media.maxHeight\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.cropMaxCharacters\">\n                    <value index=\"vDEF\"></value>\n                </field>\n                <field index=\"settings.templateLayout\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>','',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','','','','','',0,0,0,0,0,0,'default','','',0,NULL,4),
(19,'',1,1724684137,1724684137,0,0,0,0,'',96,0,0,0,0,NULL,0,'',0,0,0,0,'textteaser','Some Text','','',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,0,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','','With teaser','1.3333333333333',10,'','','','default',NULL,'','',0,'','default','default','#FFFFFF','#333333','','','',0,0,0,0,0,0,'default','','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',2),
(20,'',1,1724859121,1724859121,0,0,0,0,'',2,0,0,0,0,NULL,0,'',0,0,0,0,'texticon','','','',0,0,0,0,0,0,0,1,0,0,0,'default',0,'','',NULL,NULL,8,'','',0,'0','',1,0,NULL,0,'','','',0,0,NULL,'',0,'','','',NULL,124,0,0,0,0,NULL,0,0,0,'','',NULL,'1.3333333333333',10,'','','','default',NULL,'','',0,'left','default','square','#FFFFFF','#333333','','','',0,0,0,0,0,0,'default','','none',0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"behaviour\">\n                    <value index=\"vDEF\">cover</value>\n                </field>\n                <field index=\"parallax\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"fade\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"filter\">\n                    <value index=\"vDEF\"></value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',2);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_accordion_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_accordion_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_accordion_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_accordion_item`
--

LOCK TABLES `tx_bootstrappackage_accordion_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_accordion_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_card_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_card_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_card_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `image` int(11) NOT NULL DEFAULT 0,
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `link_title` varchar(255) NOT NULL DEFAULT '',
  `link_icon_set` varchar(255) NOT NULL DEFAULT '',
  `link_icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `link_icon` int(10) unsigned DEFAULT 0,
  `link_class` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_card_group_item`
--

LOCK TABLES `tx_bootstrappackage_card_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_card_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_carousel_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_carousel_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_carousel_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `item_type` varchar(255) NOT NULL DEFAULT '',
  `layout` varchar(255) NOT NULL DEFAULT '',
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` smallint(5) unsigned NOT NULL DEFAULT 1,
  `header_position` varchar(255) NOT NULL DEFAULT 'center',
  `header_class` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `subheader_layout` smallint(5) unsigned NOT NULL DEFAULT 2,
  `subheader_class` varchar(255) NOT NULL DEFAULT '',
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `button_text` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `image` int(10) unsigned DEFAULT 0,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `text_color` varchar(255) NOT NULL DEFAULT '',
  `background_color` varchar(255) NOT NULL DEFAULT '',
  `background_image` int(10) unsigned DEFAULT 0,
  `background_image_options` mediumtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_carousel_item`
--

LOCK TABLES `tx_bootstrappackage_carousel_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_carousel_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_icon_group_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_icon_group_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_icon_group_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `link` varchar(1024) NOT NULL DEFAULT '',
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_icon_group_item`
--

LOCK TABLES `tx_bootstrappackage_icon_group_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_icon_group_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_tab_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_tab_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_tab_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `media` int(10) unsigned DEFAULT 0,
  `mediaorient` varchar(60) NOT NULL DEFAULT 'left',
  `imagecols` smallint(5) unsigned NOT NULL DEFAULT 1,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_tab_item`
--

LOCK TABLES `tx_bootstrappackage_tab_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_tab_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_bootstrappackage_timeline_item`
--

DROP TABLE IF EXISTS `tx_bootstrappackage_timeline_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_bootstrappackage_timeline_item` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `tt_content` int(10) unsigned DEFAULT 0,
  `date` datetime DEFAULT NULL,
  `header` varchar(255) NOT NULL DEFAULT '',
  `bodytext` text DEFAULT NULL,
  `icon_set` varchar(255) NOT NULL DEFAULT '',
  `icon_identifier` varchar(255) NOT NULL DEFAULT '',
  `icon_file` int(10) unsigned DEFAULT 0,
  `image` int(10) unsigned DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_bootstrappackage_timeline_item`
--

LOCK TABLES `tx_bootstrappackage_timeline_item` WRITE;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_bootstrappackage_timeline_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_extensionmanager_domain_model_extension`
--

DROP TABLE IF EXISTS `tx_extensionmanager_domain_model_extension`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_extensionmanager_domain_model_extension` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `extension_key` varchar(60) NOT NULL DEFAULT '',
  `repository` int(11) NOT NULL DEFAULT 1,
  `remote` varchar(100) NOT NULL DEFAULT 'ter',
  `version` varchar(15) NOT NULL DEFAULT '',
  `alldownloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `downloadcounter` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(150) NOT NULL DEFAULT '',
  `description` mediumtext DEFAULT NULL,
  `state` int(11) NOT NULL DEFAULT 0,
  `review_state` int(11) NOT NULL DEFAULT 0,
  `category` int(11) NOT NULL DEFAULT 0,
  `serialized_dependencies` mediumtext DEFAULT NULL,
  `author_name` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `ownerusername` varchar(50) NOT NULL DEFAULT '',
  `md5hash` varchar(35) NOT NULL DEFAULT '',
  `update_comment` mediumtext DEFAULT NULL,
  `authorcompany` varchar(255) NOT NULL DEFAULT '',
  `integer_version` int(11) NOT NULL DEFAULT 0,
  `current_version` int(11) NOT NULL DEFAULT 0,
  `lastreviewedversion` int(11) NOT NULL DEFAULT 0,
  `documentation_link` varchar(2048) DEFAULT NULL,
  `distribution_image` varchar(255) DEFAULT NULL,
  `distribution_welcome_image` varchar(255) DEFAULT NULL,
  `last_updated` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `versionextrepo` (`extension_key`,`version`,`remote`),
  KEY `index_extrepo` (`extension_key`,`remote`),
  KEY `index_versionrepo` (`integer_version`,`remote`,`extension_key`),
  KEY `index_currentversions` (`current_version`,`review_state`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_extensionmanager_domain_model_extension`
--

LOCK TABLES `tx_extensionmanager_domain_model_extension` WRITE;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_extensionmanager_domain_model_extension` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_link`
--

DROP TABLE IF EXISTS `tx_news_domain_model_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_link` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `parent` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `uri` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `news` (`parent`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_link`
--

LOCK TABLES `tx_news_domain_model_link` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `editlock` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `starttime` int(11) NOT NULL DEFAULT 0,
  `endtime` int(11) NOT NULL DEFAULT 0,
  `fe_group` varchar(100) NOT NULL DEFAULT '',
  `notes` text DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `t3_origuid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `teaser` text DEFAULT NULL,
  `bodytext` mediumtext DEFAULT NULL,
  `datetime` bigint(20) NOT NULL DEFAULT 0,
  `archive` bigint(20) NOT NULL DEFAULT 0,
  `author` tinytext DEFAULT NULL,
  `author_email` tinytext DEFAULT NULL,
  `categories` int(11) NOT NULL DEFAULT 0,
  `related` int(11) NOT NULL DEFAULT 0,
  `related_from` int(11) NOT NULL DEFAULT 0,
  `related_files` tinytext DEFAULT NULL,
  `fal_related_files` int(10) unsigned DEFAULT 0,
  `related_links` int(11) NOT NULL DEFAULT 0,
  `type` varchar(100) NOT NULL DEFAULT '0',
  `keywords` text DEFAULT NULL,
  `description` text DEFAULT NULL,
  `tags` int(11) NOT NULL DEFAULT 0,
  `media` text DEFAULT NULL,
  `fal_media` int(10) unsigned DEFAULT 0,
  `internalurl` text DEFAULT NULL,
  `externalurl` text DEFAULT NULL,
  `istopnews` int(11) NOT NULL DEFAULT 0,
  `content_elements` int(11) NOT NULL DEFAULT 0,
  `path_segment` varchar(2048) DEFAULT NULL,
  `alternative_title` tinytext DEFAULT NULL,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `import_id` varchar(100) NOT NULL DEFAULT '',
  `import_source` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `sys_language_uid_l10n_parent` (`sys_language_uid`,`l10n_parent`),
  KEY `path_segment` (`path_segment`(185),`uid`),
  KEY `import` (`import_id`,`import_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news`
--

LOCK TABLES `tx_news_domain_model_news` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news` DISABLE KEYS */;
INSERT INTO `tx_news_domain_model_news` VALUES
(1,8,1718963138,1718884662,0,0,0,'{\"type\":\"\",\"istopnews\":\"\",\"title\":\"\",\"path_segment\":\"\",\"teaser\":\"\",\"datetime\":\"\",\"archive\":\"\",\"bodytext\":\"\",\"content_elements\":\"\",\"fal_media\":\"\",\"fal_related_files\":\"\",\"categories\":\"\",\"related\":\"\",\"related_links\":\"\",\"tags\":\"\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"notes\":\"\"}',0,0,0,0,0,'','',NULL,0,0,0,0,0,0,0,'Anne Ezurike','Software Developer','<p>Some write up to see how it looks. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distrib ution of letters, as opposed to using \'Content here, content here.</p>',1718883299,0,'','',1,0,0,NULL,0,0,'0','','',0,NULL,1,NULL,NULL,1,0,'anne-ezurike','','',0.5,'',''),
(2,8,1718908395,1718905440,0,0,0,'{\"type\":\"\",\"istopnews\":\"\",\"title\":\"\",\"path_segment\":\"\",\"teaser\":\"\",\"datetime\":\"\",\"archive\":\"\",\"bodytext\":\"\",\"content_elements\":\"\",\"fal_media\":\"\",\"fal_related_files\":\"\",\"categories\":\"\",\"related\":\"\",\"related_links\":\"\",\"tags\":\"\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"notes\":\"\"}',0,0,0,0,0,'','',NULL,0,0,0,0,0,0,0,'Austine Iheanacho','Some writeup about Austin','',1718905019,0,'','',1,0,0,NULL,0,0,'0','','',0,NULL,1,NULL,NULL,1,0,'austine-iheanacho','','',0.5,'',''),
(3,8,1718987063,1718987021,0,0,0,'{\"type\":\"\",\"istopnews\":\"\",\"title\":\"\",\"path_segment\":\"\",\"teaser\":\"\",\"datetime\":\"\",\"archive\":\"\",\"bodytext\":\"\",\"content_elements\":\"\",\"fal_media\":\"\",\"fal_related_files\":\"\",\"categories\":\"\",\"related\":\"\",\"related_links\":\"\",\"tags\":\"\",\"author\":\"\",\"author_email\":\"\",\"keywords\":\"\",\"description\":\"\",\"alternative_title\":\"\",\"sitemap_changefreq\":\"\",\"sitemap_priority\":\"\",\"sys_language_uid\":\"\",\"hidden\":\"\",\"starttime\":\"\",\"endtime\":\"\",\"fe_group\":\"\",\"editlock\":\"\",\"notes\":\"\"}',0,0,0,0,0,'','',NULL,0,0,0,0,0,0,0,'Derrick Chimdalu','Junge','<p>Some small writeup about me</p>',1718986730,0,'','',0,0,0,NULL,0,0,'0','','',0,NULL,1,NULL,NULL,0,0,'derrick-chimdalu','D-boy','',0.5,'','');
/*!40000 ALTER TABLE `tx_news_domain_model_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_related_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_related_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_related_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_related_mm`
--

LOCK TABLES `tx_news_domain_model_news_related_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_related_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_tag_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_tag_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_tag_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid_local`,`uid_foreign`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_tag_mm`
--

LOCK TABLES `tx_news_domain_model_news_tag_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_tag_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_news_ttcontent_mm`
--

DROP TABLE IF EXISTS `tx_news_domain_model_news_ttcontent_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_news_ttcontent_mm` (
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_news_ttcontent_mm`
--

LOCK TABLES `tx_news_domain_model_news_ttcontent_mm` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_news_ttcontent_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_news_domain_model_tag`
--

DROP TABLE IF EXISTS `tx_news_domain_model_tag`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tx_news_domain_model_tag` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `pid` int(11) NOT NULL DEFAULT 0,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `deleted` smallint(6) NOT NULL DEFAULT 0,
  `hidden` smallint(6) NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(11) NOT NULL DEFAULT 0,
  `l10n_diffsource` mediumtext DEFAULT NULL,
  `l10n_source` int(11) NOT NULL DEFAULT 0,
  `notes` text DEFAULT NULL,
  `l10n_state` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `cruser_id` int(11) NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `slug` varchar(2048) DEFAULT NULL,
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `seo_description` text DEFAULT NULL,
  `seo_headline` varchar(255) NOT NULL DEFAULT '',
  `seo_text` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_news_domain_model_tag`
--

LOCK TABLES `tx_news_domain_model_tag` WRITE;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_news_domain_model_tag` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-08-30 17:04:52
